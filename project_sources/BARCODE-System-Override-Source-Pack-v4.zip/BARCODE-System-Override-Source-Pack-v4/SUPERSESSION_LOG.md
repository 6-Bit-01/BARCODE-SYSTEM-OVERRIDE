# Supersession Log

## Source Pack v3 → v4

Source Pack v4 retains v3's seven-level campaign, cast/canon locks, Level 1 art/intro constraints, progression, finale, asset audit, and production plan. It supersedes every instruction to test or merge PR #4 and every architecture statement that treated one Level 1-derived beat/bar/phrase clock as a campaign-wide authority.

The audited v3 archive is retained byte-for-byte at `references/BARCODE-System-Override-Source-Pack-v3-SUPERSEDED.zip`; SHA-256 `a465dd37be6b7a6b9766f94f0fadc7c34ca061624dd06a1151f2000804799078`.

PR #4 remains historical evidence only: it was built from `main` after PR #3, passed static/unit checks, and was rejected by the owner before merge. Future code begins fresh from `main`; no PR #4 commit, patch, or branch is reused.

v4 locks seven distinct gameplay songs and profiles. Level 7's compatible Full Mix is a separate arrangement whose layers are unlocked by progression IDs; it is not an overlay of the other level songs.

## Source Pack v2 → v3

Source Pack v2 remains useful for provenance, four-character boundaries, the simulation premise, 9 Bit's origin, intro/art locks, and the Codex/Makko workflow. It is superseded where it describes the project as cleanup-only, leaves the level count/order open, uses a generic seven-slot scaffold, or treats completion of Level 1 as out of scope.

The audited v2 archive SHA-256 is `5fe76d38bd6d354926627ce72285efe7c307040d2d8cfe8424fb97605648d2b9`. It contained 26 Markdown/JSON/TXT paths, no code, and no asset binaries or direct game-asset URLs.

## Legacy repository concepts

The following remain historical evidence but not future design authority:

- City Scrambler;
- 20-enemy quota;
- destroyable jammer;
- fast-fall invincibility and 999-damage stomp;
- advertised-but-disabled dash;
- random endless enemy flow;
- random lore spawn timers;
- five-level maximum;
- victory hooks that do not complete a campaign;
- speculative lore lines that define origins without approval.

## PR plan history

The v2 PR-001 prompt is completed history, not the next prompt. PRs #1–#3 are merged. PR #4 is owner-rejected and must close unmerged. The v4 roadmap begins with a fresh level-aware music-profile/transport PR from `main`, then lifecycle, enemy, combat, authored Level 1, and campaign-kernel work.
