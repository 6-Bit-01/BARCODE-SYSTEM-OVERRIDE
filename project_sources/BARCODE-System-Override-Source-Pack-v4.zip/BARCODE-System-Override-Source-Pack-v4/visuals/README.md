# Visual Audit Sheets

- `LEVEL_1_ASSET_CONTACT_SHEET.png`: current title, far background, street foreground, Jammer, lore object, and representative traffic frames. It demonstrates why Level 1 should reuse its identity while adding collision-readable props and aspect-correct layer handling.
- `LOCKED_INTRO_CONTACT_SHEET.png`: the nine unique approved intro images. The audited runtime has eleven image entries because SO8 is currently referenced three times. This is verification evidence, not a redesign brief.
- `CURRENT_SPRITES_PARTIAL_CONTACT_SHEET.png`: partial locally reachable Makko exports used to confirm transparency, scale, and animation-sheet structure. `assets/ASSET_REGISTRY.json` and the checked-in repo manifest remain authority for all 14 animation records.

The audit observed eleven intro image entries and twelve subtitle records; the final subtitle appears unreachable. Treat that as a locked-presentation verification item. Do not silently reorder, replace, rewrite, or insert 9 Bit into the prologue.
