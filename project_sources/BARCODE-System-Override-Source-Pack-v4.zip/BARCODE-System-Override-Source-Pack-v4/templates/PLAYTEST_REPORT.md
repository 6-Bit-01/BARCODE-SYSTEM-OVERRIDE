# Playtest Report

- Build / commit / PR:
- Date / tester:
- Browser / OS / device / controller:
- Start state: fresh / existing save / imported fixture
- Level and checkpoint:
- Settings changed from default:

## Verdict

PASS / PASS WITH NOTES / FAIL

## Route taken

Record main/optional path, collected items/lore, deaths, timing/judgment grade when applicable, pause/restart actions, and approximate clear time.

## Findings

| Severity | Time/location | Expected | Observed | Reproduction | Capture |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## Required checks

- [ ] every basic action worked with timing judgment unavailable
- [ ] if this profile enables judgment, its bonus was understandable but not mandatory
- [ ] no invisible required platform/door/hazard
- [ ] pause froze gameplay and audio timing coherently
- [ ] restart restored the correct checkpoint without duplicates
- [ ] guaranteed reward granted once
- [ ] missing optional reward did not block completion
- [ ] keyboard/gamepad parity
- [ ] reduced flash/motion check
- [ ] no new console errors or accumulating timers/listeners/audio
- [ ] community cameos were legible, respectful, and non-disruptive

## Feel notes

Separately record controls, camera, difficulty, timing readability when applicable, audio mix, visual readability, pacing, story comprehension, and anything that felt unlike BARCODE.
