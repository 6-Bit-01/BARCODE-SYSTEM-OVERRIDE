# Community Cameo Approval Card

- Registry alias only:
- No real name stored: yes / no
- Level / location:
- Tier: ambient / story / functional
- Exact use: sign, terminal, portrait, dialogue, voice, music, merchant, route, assist, power-up, other
- Tone: supportive / neutral / memorial / comic / other
- Could the use be read as hostile, capturable, corrupt, defeated, or mocking: yes / no
- Likeness used: yes / no
- Voice used: yes / no
- Music used: yes / no
- Written permission required: yes / no
- Permission source/date/terms:
- Credit text:
- Removable fallback ID/content:
- Owner approval: PASS / PASS WITH NOTES / FAIL

Rules: cameos never become playable; W3T TDDY stays an ally; never use `Brownout`; do not add a separate Bini Easter egg because Cache Back already represents Call'em Bini.

