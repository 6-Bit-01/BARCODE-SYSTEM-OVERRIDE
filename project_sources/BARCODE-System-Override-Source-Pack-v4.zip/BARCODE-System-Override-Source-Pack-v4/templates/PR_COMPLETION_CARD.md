# PR Completion Card

- PR / title / link:
- Base commit:
- Head commit:
- Branch:
- Scope statement:
- Explicit non-goals:

## Changed files

For every changed file, state why it is required by this PR. Flag generated or asset files separately.

## Verification

| Command / manual route | Result | Evidence |
|---|---|---|
|  |  |  |

- JavaScript syntax: PASS / FAIL
- `npm test`: PASS / FAIL
- targeted tests: PASS / FAIL
- browser smoke: PASS / PASS WITH NOTES / FAIL / owner required
- duplicate Makko project: PASS / PASS WITH NOTES / FAIL / owner required
- performance/resource comparison:
- save migration/recovery impact:
- accessibility/input impact:

## Risks and rollback

- Known risks:
- Deferred work:
- Rollback/revert path:
- Legacy files intentionally retained and why:

## Owner checklist

Give a numbered, five-to-ten-minute route with expected observations. End with owner verdict: PASS / PASS WITH NOTES / FAIL. Do not merge without the requested owner smoke when presentation, timing, audio, camera, sprites, or restart behavior changed.

