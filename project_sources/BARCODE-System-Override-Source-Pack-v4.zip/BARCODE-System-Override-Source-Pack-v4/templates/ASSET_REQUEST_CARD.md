# Asset Request Card

Duplicate this card for every asset group. Do not commission final art before its greybox dependency is proven.

## Identity

- Stable ID:
- Level / screen:
- Character / object:
- Purpose in play:
- Priority:
- Production owner: Makko / image generation / audio / code-native / other
- Existing reference files or IDs:
- Owner approval required before production: yes / no

## Technical delivery

- Source canvas / frame size:
- On-screen target size:
- Format and transparency:
- Animation names:
- FPS and frame-count range:
- Bottom-center anchor:
- Gameplay hitbox / hurtbox / interaction box:
- Flip/rotation rules:
- Palette / contrast / accessibility rules:
- Maximum compressed and decoded size:
- Stable local filename/path:
- Remote provenance URL, if any:
- Fallback behavior:

## Art direction

- Approved BARCODE references:
- Dead-media / public-access / obsolete-computing details:
- Silhouette and anticipation requirements:
- Must preserve:
- Must avoid:

## Acceptance

- [ ] correct identity/reference
- [ ] transparent/edge quality
- [ ] dimensions and anchor validated
- [ ] animation names/fps/frames validated
- [ ] hitboxes readable at gameplay scale
- [ ] palette and reduced-flash check
- [ ] pause/restart/flip/alpha check
- [ ] file-size budget met
- [ ] source/export/hash/credit recorded
- [ ] owner verdict: PASS / PASS WITH NOTES / FAIL

