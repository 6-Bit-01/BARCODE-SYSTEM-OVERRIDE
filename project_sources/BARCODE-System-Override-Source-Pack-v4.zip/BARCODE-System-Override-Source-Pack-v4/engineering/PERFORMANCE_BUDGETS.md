# Performance Budgets

These are production gates, not claims about the current build. Confirm the minimum target device before final lock; until then, test a midrange integrated-GPU laptop at 1920×1080 and a throttled browser profile.

| Metric | Target | Hard floor / cap | Measurement point |
|---|---:|---:|---|
| frame rate | 60 FPS | stable 30 FPS minimum | worst authored encounter per level |
| frame CPU time | ≤ 12 ms median | ≤ 28 ms p95 at 30-FPS target | performance trace, debug off |
| long tasks | none during play | no task > 100 ms | cold load and peak encounter |
| canvas readback | 0/frame | 0 in normal mode | all levels |
| active animation loops | 1 | 1 | title→level→restart→exit |
| unowned timers/listeners/sources after exit | 0 | 0 | ten transition cycles |
| critical initial transfer | ≤ 8 MB compressed | ≤ 15 MB | title plus first interaction |
| Level 1 critical transfer | ≤ 20 MB compressed | ≤ 30 MB | first playable frame |
| later-level critical transfer | ≤ 25 MB compressed | ≤ 40 MB | per cartridge |
| decoded image growth after exit | returns near baseline | < 20 MB retained delta | ten level cycles |
| active enemies/projectiles/particles | explicit per-level caps | no unbounded arrays | worst encounter |
| save payload | < 128 KB | < 512 KB | late-game all collectibles |
| save write | < 16 ms main-thread | never per frame | checkpoint/result/settings |
| input-to-action | < 50 ms p95 | < 100 ms | keyboard and gamepad |
| audio drift at loop | inaudible | < 10 ms session discontinuity | ten loops or full-track restarts per profile |

## Cartridge caps to establish in greybox

| Level | Must cap |
|---|---|
| 1 | enemies, crowds, particles, flybys, prop draw calls, hit sparks |
| 2 | visible traffic, roadside segments, horizon layers, collision checks |
| 3 | enemies, enemy bullets, player projectiles, debris, explosions |
| 4 | cascade passes, particles, board animations, queued audio cues |
| 5 | map chunks, NPCs, battle effects, menu portraits, cached dialogue |
| 6 | ray columns/resolution scale, sprite billboards, rays per frame, audio sources |
| 7 | Level 6 renderer caps plus party effects, doors, archive media, boss FX |

## Required instrumentation

- production logger off by default;
- one HUD toggle reporting FPS, frame time, entities, timers/listeners/audio sources, decoded asset estimate, and current adapter;
- `performance.mark` around preload, enter, first render, checkpoint, result, and exit;
- transition soak test that records resource counts after every cycle;
- optional low-resolution renderer scale and CRT intensity for minimum hardware;
- deterministic stress scenes committed as development fixtures, not reachable by normal player keys.

## Immediate repository fixes

The current full-frame 1920×1080 JavaScript CRT pixel pass, large remote GIF traffic, random main-thread audio generation, repeated remote probes, unmanaged timers/audio sources, and approximately 1,440 console calls violate these budgets. Address them in the order recorded in `docs/08_PERFORMANCE_AND_COMPATIBILITY.md`; do not conceal them by lowering content density.
