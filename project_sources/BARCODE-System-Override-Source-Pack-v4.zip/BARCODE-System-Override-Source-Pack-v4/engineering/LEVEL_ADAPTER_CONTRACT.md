# Level Adapter Contract

This contract keeps seven different genres inside one campaign without allowing a level to inherit or mutate another level's globals.

## Required shape

```js
window.BARCODE.registerLevel('level-00', function createLevelAdapter() {
  return {
    id: 'level-00',
    mode: 'development',
    async preload(context) {},
    async enter(context, checkpoint) {},
    handleAction(action, phase, value) {},
    update(deltaMs) {},
    render(frame) {},
    serializeCheckpoint() { return null; },
    pause() {},
    resume() {},
    async exit() {}
  };
});
```

No adapter starts its own animation loop. `LevelDirector` is the only caller of `update` and `render`.

## Registration API

`window.BARCODE.levels` owns factories, not live adapter instances.

```js
BARCODE.registerLevel(id, factory);   // registers once; duplicate ID throws
BARCODE.hasLevel(id);                 // boolean
BARCODE.createLevel(id);              // evaluates factory now; returns a fresh adapter
BARCODE.listLevels();                 // sorted registered IDs for diagnostics
BARCODE.unregisterLevelForTest(id);   // test builds only; throws in production
```

Registration validates an ID against `level-01` through `level-07` plus explicit `dev-*` fixtures, validates that `factory` is a function, and does not evaluate it. `createLevel` evaluates the factory only when `LevelDirector` begins a load, validates the returned contract, and never caches the live instance after exit. A second registration for the same ID is always an error rather than load-order override. Production code cannot unregister or replace a factory.

## Context surface

An adapter receives an immutable context containing only:

- `assets`: request/release stable asset IDs;
- `audio`: level-scoped SFX/voice/ambience buses;
- `music`: the one active `MusicSession`, bound to this level's validated profile; beat/bar fields exist only when that profile supports them;
- `input`: semantic actions and active binding display;
- `campaign`: read-only campaign snapshot plus explicit checkpoint/result commands;
- `events`: level-scoped publish/subscribe;
- `scope`: tracked timers, listeners, sources, DOM overlays, workers, and disposables;
- `settings`: accessibility/display/audio/calibration snapshot;
- `surface`: canvas/context/viewport abstraction;
- `logger`: gated diagnostic output.

The adapter does not receive `window`, an enemy singleton, the legacy game object, or another adapter. Temporary compatibility access for Level 1 must be named, documented, and deleted by a scheduled PR.

## Lifecycle rules

1. `preload` may fetch/decode but may not start gameplay, a music session, timers, or listeners.
2. `enter` creates the level state exactly once and restores only validated checkpoint data.
3. `handleAction` is the only input ingress. Actions use `started`, `changed`, and `ended` phases.
4. `update` receives a capped millisecond delta. A cartridge may run its own fixed simulation steps inside that call.
5. `render` has no campaign writes and does not advance simulation.
6. `pause` is idempotent. The shared owner suspends the active music session/mixer first; the adapter freezes local presentation.
7. `resume` is idempotent and cannot create duplicate listeners, loops, or sources.
8. `serializeCheckpoint` returns JSON-safe level-local state only. Persistent items and lore are recorded through campaign commands.
9. `exit` is safe after partial preload/enter failure and may be called more than once.
10. After `exit`, the adapter owns zero live timers, listeners, audio sources, DOM overlays, workers, animation loops, or object URLs.

## Semantic actions

Shared actions are `move.x`, `move.y`, `aim.x`, `aim.y`, `jump`, `primary`, `secondary`, `interact`, `party.next`, `party.previous`, `menu`, `pause`, `confirm`, and `back`. A cartridge can declare namespaced actions such as `puzzle.rotate` or `racer.brake`, but cannot bind raw keys itself.

For the finished Level 1 design, `primary` always attacks. Verified or explicit `legacy-compatibility` Level 1 judgment may change the reward, never permission to act. Base movement remains left/right and one jump. No-grid levels expose no timing grade or judgment requirement.

## Result boundary

An adapter completes through one command:

```js
context.campaign.completeLevel({
  levelId: 'level-01',
  checkpointId: 'complete',
  guaranteedItems: ['stem.voice'],
  optionalItems: ['module.beat_anchor'],
  loreFound: ['lore.l01.01'],
  stats: { clearMs: 0, deaths: 0, timingGrade: null }
});
```

The store validates reward IDs against `data/campaign.json`; adapters cannot invent persistent flags.

## Contract tests

Every cartridge must pass:

- preload failure then retry;
- enter, ten updates, render, pause twice, resume twice, exit twice;
- restart ten times without increasing tracked resource counts;
- checkpoint JSON round trip and malformed checkpoint fallback;
- keyboard/gamepad action parity for every required action;
- completion with timing judgment unavailable, plus worst timing grade when the profile enables judgment;
- deterministic guaranteed reward grant;
- no optional reward still permits campaign completion;
- no update or audio advance while paused.
