# Level Music Profile Contract

## Purpose

Every major level has a different gameplay song. Shared code may own playback, pause, resume, position, and teardown, but the active level owns the profile that explains its song. There is no campaign-wide BPM, meter, phrase size, loop, judgment rule, cue map, or stem layout.

The architecture must allow constant tempo, later tempo/meter changes, free-time intros, authored markers, human-feel timing, or no useful grid. Missing metadata is explicit and never permission to guess a fallback.

## Metadata status

- `unverified`: timing-dependent gameplay and judgment are disabled.
- `legacy-compatibility`: allowed only for `level-01.main` while migrating the existing 146 BPM, 4/4, four-bar presentation, and 211-second manual restart behavior. It may preserve existing Level 1 judgment, but is never an approved production measurement or a default.
- `verified`: owner/audio evidence has confirmed the profile metadata required by its enabled capabilities.

No other level may register `legacy-compatibility`.

## Canonical time domains

- `audioTimeSec`: `AudioContext.currentTime`.
- `sourceAnchorAudioSec`: the exact scheduled Web Audio start for the active required sources.
- `sourceOffsetTrackSec`: decoded track position used when sources start or resume.
- `trackTimeSec`: `(audioTimeSec - sourceAnchorAudioSec) + sourceOffsetTrackSec` while running.
- `gridOriginTrackSec`: track time where musical tick zero begins. Audio before it is a free-time intro and has no grid position.
- Loop ranges are half-open: `[loopStartSec, loopEndSec)`.
- Every effective source start, resume, coordinated manual restart, seek, stop/reload, or profile change advances a `generation`. Events from older generations are invalid. An idempotent duplicate `start()` against the same active state does not advance generation. A native wrap inside one looping Level 1 source is not a transport loop or generation boundary; the coordinated 211-second manual restart is.

Pause captures `trackTimeSec`. Resume schedules a new source anchor at that captured offset and starts a new generation. Profile selection always uses an exact profile ID. Missing or invalid profiles create a no-profile/degraded session; they never inherit Level 1, the previous profile, 146 BPM, or 4/4.

## Profile shape

```json
{
  "profileId": "level-01.main",
  "levelId": "level-01",
  "runtimeRegistration": true,
  "metadataStatus": "legacy-compatibility",
  "arrangement": {
    "sources": [
      {
        "sourceId": "foundation",
        "assetId": "audio.level-01.foundation",
        "url": null,
        "required": true,
        "gain": 1,
        "offsetSec": 0,
        "nativeLoop": true,
        "fallbackRole": "required-or-degraded"
      }
    ]
  },
  "playback": {
    "startTrackSec": 0,
    "loop": null,
    "endPolicy": "level-controlled",
    "legacyManualRestartSec": null
  },
  "timeline": {
    "mode": "fixed-tempo",
    "ppq": 480,
    "gridOriginTrackSec": 0,
    "tempoMap": [
      {"atTrackSec": 0, "atTick": 0, "quarterBpm": 0, "transition": "step"}
    ],
    "meterMap": [
      {"atTick": 0, "numerator": 4, "denominator": 4, "startBar": 1}
    ],
    "sections": [],
    "phraseMarkers": []
  },
  "cues": [],
  "judgmentRules": [],
  "legacyCompatibility": {
    "firstBoundaryOffsetBeats": null,
    "establishmentBeatCount": 32,
    "phraseCycleTicks": 7680
  }
}
```

Zero tempo values above show field shape only and are not valid runtime metadata. `url` is a temporary Level 1 migration field until the future AssetService resolves every stable `assetId`; it must preserve the existing URLs exactly. The Level 1 profile records the actual current constants after inspection, including its native-source loop flags, first-boundary phase, 32-beat establishment, 16-beat/7680-tick phrase presentation, and manual restart policy. Other unverified planning profiles are not registered and may not use `legacyCompatibility`.

## Timeline modes

- `none`: playback position only.
- `markers-only`: exact track-time markers/sections, no beat grid.
- `fixed-tempo`: one verified or legacy-compatibility tempo segment; meter is optional unless bar output is requested.
- `tempo-map`: ordered step-tempo segments plus optional meter changes. This is a planned extension, not required in the first replacement PR.

Tempo entries anchor both track seconds and musical ticks. `quarterBpm` is explicit so compound meter is unambiguous. The first future `tempo-map` extension supports step changes only; ramps require a later schema version. Meter changes occur on declared bar boundaries and provide `atTick`, numerator, denominator, and `startBar`. Phrases are explicit markers or ranges—never inferred as four bars.

## Cues and polling

Cues use either exact `atTrackSec`, exact `atTick`, or a section/phrase marker ID. Each cue declares:

- `occurrence`: `once-per-session`, `once-per-loop`, or `every-crossing`;
- `hitchPolicy`: `bounded-all`, `latest-only`, or `skip`;
- `seekPolicy`: `do-not-replay`, `replay-if-crossed`, or `reset`;
- optional visual/degraded fallback ID.

The existing single gameplay frame owner calls `poll(audioTimeSec)`. The music system creates no RAF and no recursive beat timer. `poll` returns a frozen batch containing the current snapshot plus ordered bounded boundary/cue events tagged with profile ID, generation, and coordinated loop iteration. Consumers may instead subscribe through `onBoundary(type, listener)` / `onCue(id, listener)`; polling remains the only event pump.

## Judgment rules

A named rule declares its grid unit and windows, for example:

```json
{
  "id": "level-01.attack",
  "target": "quarter-note",
  "windowsMs": {"perfect": 60, "excellent": 100},
  "calibrationOffsetMs": 0
}
```

`judgeInput(ruleId, audioTimeSec)` is unavailable for `none`, `markers-only`, and ordinary `unverified` profiles. The only temporary exception is Level 1's `legacy-compatibility` rule, which preserves the existing thresholds/formula until the owner verifies the track.

## Runtime boundary

The shared service exposes one active session:

```js
{
  load(profileId),
  start(options),
  poll(audioTimeSec),
  pause(),
  resume(),
  seek(trackTimeSec, options),
  stop(),
  sample(audioTimeSec),
  onBoundary(type, listener),
  onCue(id, listener),
  judgeInput(ruleId, audioTimeSec)
}
```

- `sample()` returns only values supported by the active profile.
- `seek()` belongs to the full contract but may be deferred until a checkpoint/level needs it.
- Level code subscribes to stable cue IDs, not raw global counters.
- The Level Adapter's disposable scope owns cue listeners and releases them on `exit()`.
- SFX, dialogue, stingers, and ambience use mixer buses and never become competing transports.

## Track and Stem Key separation

- Levels 1–7 each use a distinct gameplay song/profile.
- Production-ready sources/stems inside one level arrangement share that arrangement's export origin, sample rate, decoded length/loop boundaries, and timeline. Level 1's `legacy-compatibility` arrangement is explicitly exempt until re-exported; PR #5 preserves its unequal decoded lengths and current native loops/manual restart.
- The six campaign Stem Keys are collectible/progression IDs, not loadable audio asset IDs.
- Level 7 maps those keys explicitly to separately produced layer assets such as `stem.voice` → `audio.level-07.fullmix.voice`.
- The unrelated level songs are never played as Full Mix layers.

## PR #5 implementation slice

The first replacement PR implements profile validation/immutability, exact-ID selection, multi-source Level 1 compatibility data, playback/no-grid and fixed-tempo modes, inert validation of reserved marker fields, exact Web Audio anchoring, current Level 1 judgment, and transport-owned cleanup. Synthetic fixtures prove at least two different fixed tempos/meters/grid origins/playback policies plus no-grid behavior.

Tempo/meter changes, seek, adaptive arrangement authoring, and final gameplay cues remain contract-defined extensions until an approved track or checkpoint requires them. They must not be half-implemented inside PR #5.

## Production validation

1. Record exact asset provenance and stable asset IDs.
2. Verify duration, sample rate, channels, loudness, start/grid origin, and loop/end policy.
3. Supply fixed tempo, a tempo/meter map, or explicit markers; do not infer silently.
4. Test start, pause/resume, restart, checkpoint resume where supported, one loop boundary, and teardown.
5. Confirm ordinary gameplay works with judgment unavailable and audio degraded.
