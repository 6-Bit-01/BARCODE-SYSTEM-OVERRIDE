# Level 1 Vertical-Slice Blueprint

This is the implementable PR #9/#11 brief. All tuning values are working baselines and require owner feel approval; the control/canon constraints are fixed.

## Normalized layout

Author geometry in screen-width units so the stage survives internal-resolution work. Target about five camera-widths total, with one checkpoint at the start of sections 3 and 5.

| Range | Section | Main route | Optional/readability work |
|---|---|---|---|
| 0.00–0.85 | Boot Alley | flat move/jump/attack tutorial, one Virus, one Corrupted | skippable prompts; no locked arena |
| 0.85–2.05 | H3LLCAT Block | street route with crates/shelter and one short scaffold step | awning→speaker→scaffold upper route; Beat Anchor at its end; every rise fits one measured jump |
| 2.05–3.05 | Dead Channel Plaza | clear two authored waves to restore plaza exit | Lore #2 alcove, NUL.TV screen, first Firewall introduction |
| 3.05–4.15 | Flyby Row | traverse two warned traffic-cue setpieces and one mixed encounter | spectacle-only reduced-motion alternative; no random car timers |
| 4.15–5.00 | Relay Stage | reach and trigger Jammer event, then boss arena | Lore #3 after trigger; pre-boss checkpoint; Studio Rat exit sighting |

The exact pixel conversion is created only after PR #8 records one-jump horizontal/vertical reach at normal speed. A stage validator rejects required vertical gaps above 85% of measured jump height, required horizontal gaps above 80% of measured reach, collision without a visible prop/surface, and one-way drops with no clear return or checkpoint.

## Checkpoints

- `l01.boot`: new run/tutorial start;
- `l01.plaza`: after H3LLCAT Block; preserves Beat Anchor/lore sets;
- `l01.relay`: after the Jammer event, before boss introduction;
- `l01.complete`: result boundary, never a playable spawn.

Checkpoint restore resets the local encounter/prop state to its authored snapshot, not to partially dead enemy objects. Persistent items/lore remain set-valued in `CampaignStore`.

## Encounter budget

Maximum four combat enemies active, one Firewall active, and six noncombat crowd silhouettes. No spawn occurs outside the current/adjacent authored encounter group.

| Group | Composition | Teaching purpose | Gate |
|---|---|---|---|
| `boot-virus` | 1 Virus | airborne read and normal off-beat attack | none |
| `boot-corrupted` | 1 Corrupted | stare/snare commit | none |
| `block-mix` | 2 Corrupted + 1 Virus, staggered | positioning around props | milestone only; no hard door |
| `plaza-a` | 2 Corrupted | authored arena and crowd retreat | defeat group |
| `plaza-b` | 1 Firewall + 1 Virus | heavy controller plus air pressure | defeat group |
| `flyby-mix` | 1 Firewall + 2 Virus | traffic warning plus readable combat | reach exit after group |
| `relay-guard` | 2 Corrupted + 1 Firewall | final mastery before trigger | defeat group, then interact with Jammer |

Enemy defeats increment one authoritative stat exactly once. They do not unlock the Jammer through a global quota.

## Combat baseline for first tuning pass

- 6 Bit: six visible health segments; one second of post-hit grace as a working start.
- Basic attack: one base damage, always available when gameplay accepts input.
- Good beat: one resolved hit at a bounded 1.25 multiplier plus modest stagger/combo gain; no second damage call.
- Perfect beat: bounded damage multiplier no higher than 1.5, stronger stagger, small signal recovery; never required to finish.
- Virus: two base hits; Corrupted: three; Firewall: six to eight pending feel test.
- Terminal hack: bound to a visible terminal, one use per checkpoint snapshot, restores one segment; no global H key.
- Contact, enemy attacks, and traffic hazards use one damage service and cannot stack multiple hits in one grace window.

## Music cue ownership

All cues subscribe to stable IDs from the verified Level 1 music profile and are canceled by the level scope. Until that profile is verified, use explicit authored markers or readable non-musical fallbacks; never guess a BPM.

- Virus entry can use an approved hi-hat cue from the Level 1 profile;
- Corrupted stop/stare can lead an approved snare/commit marker;
- Firewall announces for a readable duration before an approved attack cue;
- traffic warning begins early enough to react before its crossing marker;
- arena waves and Jammer phases follow named section/cue IDs where useful;
- boss cadence cues create high-value stagger windows, not invulnerability removal.

Reduced-motion/flyby settings retain timing information through border lights, lane markers, captions, and audio cues.

## Jammer event

The Jammer has no health, hurtbox, damage reaction, kill credit, or target selection. Interaction after `relay-guard` starts a bounded signal-distortion sequence: foreground/bus lights desaturate, music filters briefly, the Relay gate retunes, and the boss transition becomes available. Pause freezes the sequence; restart restores the correct checkpoint state; audio nodes and timers dispose on exit.

## Working Program Director fight

The boss remains damageable at all times. Authored cadence windows improve damage/stagger/readability but never authorize the attack.

1. **Tracking Light:** columns sweep the arena after floor/sky warnings; one safe gap stays readable.
2. **Censor Bars:** broadcast bars become temporary hazards/platform silhouettes; required dodges use ground movement or one jump only.
3. **Boom Sweep:** a boom-mic arm sweeps high/low with a long readable tell; the ON AIR core exposes a stagger bonus on an authored cadence cue.
4. **Final mix:** combines one light pattern with one sweep, never all hazards simultaneously; defeat may land on a scheduled Level 1 cue but cannot wait indefinitely if audio is degraded.

If current boss art does not fit after owner review, keep the greybox behavior and replace only its presentation/identity through an approved asset card.

## Acceptance route

Complete with no Beat Anchor, no lore, worst Level 1 timing grade, keyboard, and gamepad. Repeat with upper route/all three lore. Pause during traffic, Jammer, and every boss pattern. Restart from each checkpoint ten times. Verify one loop, stable resource counts, no invisible required collision, no untelegraphed flyby damage, deterministic Voice Stem Key grant once, optional Module set once, and result/save recovery after reload.
