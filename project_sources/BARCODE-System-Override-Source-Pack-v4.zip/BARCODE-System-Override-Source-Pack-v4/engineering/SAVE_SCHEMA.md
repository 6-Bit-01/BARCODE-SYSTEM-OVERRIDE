# Save Schema

Use one versioned, JSON-safe campaign record. The first shipping implementation is **single-slot** with a retained backup: canonical key `barcode.system-override.save.v1.default`, backup key `barcode.system-override.save.v1.default.backup`, and temporary key `barcode.system-override.save.v1.default.pending`. A future multi-slot UI must namespace all three keys by validated slot ID; it is not implied by this schema. A schema change increments `schemaVersion` and ships an explicit migration. `campaignVersion` follows the content manifest independently of the save schema and source-pack version.

## Canonical example

```json
{
  "schemaVersion": 1,
  "campaignVersion": "4.0.0-planning",
  "slotId": "default",
  "revision": 12,
  "updatedAt": "2026-07-15T20:00:00.000Z",
  "current": {
    "levelId": "level-02",
    "checkpointId": "start",
    "levelState": null
  },
  "progress": {
    "unlockedLevels": ["level-01", "level-02"],
    "completedLevels": ["level-01"],
    "items": ["stem.voice", "module.beat_anchor"],
    "lore": ["lore.l01.01", "lore.l01.02", "lore.l01.03"],
    "easterEggs": ["rat.l01", "nulltv.l01"],
    "results": {
      "level-01": {"bestClearMs": 720000, "bestTimingGrade": "B", "deaths": 2}
    }
  },
  "settings": {
    "music": 0.8,
    "sfx": 0.9,
    "voice": 1,
    "calibrationMs": 0,
    "reducedFlash": false,
    "reducedMotion": false,
    "screenShake": 1,
    "headBob": 1,
    "foregroundFlybys": true,
    "crtIntensity": 0.5,
    "subtitles": true,
    "subtitleSize": 1,
    "textSpeed": 1,
    "controllerVibration": true,
    "rhythmAssist": "standard",
    "genreAssists": {
      "racerSteering": "standard",
      "runGunAim": "standard",
      "puzzleFallSpeed": "standard",
      "rpgBattleHints": true,
      "fpsAim": "standard"
    },
    "bindingsVersion": 1,
    "bindings": {
      "keyboard": {},
      "gamepad": {}
    }
  },
  "integrity": {
    "lastCleanExit": true,
    "recoveredFromBackup": false
  }
}
```

## Invariants

- IDs are drawn from `data/campaign.json`, `data/items.json`, `data/lore-plan.json`, and the Easter-egg registry.
- A completed level always grants its Stem Key exactly once.
- Item/lore/egg arrays behave as sets; duplicate grants are ignored.
- Signature Modules are optional. Missing modules cannot remove the Level 7 main route.
- Level 7 unlocks only when all six Stem Keys exist, not from a numeric `maxLevel` field.
- Save data never persists runtime object references, DOM nodes, audio nodes, callbacks, URLs, or raw input codes.
- Level-local checkpoint state is capped, validated by that adapter, and discarded safely if incompatible.
- Settings survive “new campaign”; campaign progress does not survive “erase campaign.” The single-slot first version resets campaign fields while retaining the settings object.

## Write protocol

1. Build and validate the next full record in memory.
2. Write it to a temporary/backup key.
3. Read and parse it back.
4. Promote it to the canonical key and retain the last known-good backup.
5. Increment `revision` only after successful promotion.

Write on checkpoint activation, level result, item/lore discovery, settings change, and clean exit. Do not write every frame. Browser storage errors show a non-blocking but persistent warning.

## Migration and recovery

- Unknown future versions are never overwritten; offer export/reset.
- Known older versions migrate through pure functions with fixture tests.
- Invalid IDs are quarantined in a diagnostic field rather than crashing load.
- If canonical data fails, try the last known-good backup and set `recoveredFromBackup`.
- If both fail, keep the corrupt strings available for diagnostics and offer a new slot.
- Development builds include export/import JSON; shipping import requires an explicit warning and validation.

## Level 7 read model

At Level 7 entry, create an immutable progression snapshot. Doors and combat perks query `hasItem('module.*')`; they never retain an object from a prior level. Guaranteed Stem Keys unlock their mapped layers in the separately authored Full Mix arrangement. Module effects remain bounded to the dependency matrix in `docs/04_META_PROGRESSION_AND_FINALE.md`.
