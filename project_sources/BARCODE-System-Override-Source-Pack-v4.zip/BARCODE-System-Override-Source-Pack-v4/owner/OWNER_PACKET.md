# Owner Packet

## The short version

The project has a real revival foundation but not yet a seven-level game. PRs #1–#3 are merged. PR #4 is rejected and should be closed without merge because timing is still modeled around Level 1 instead of seven different songs. The current Level 1 remains a flat random sandbox with duplicated enemy/combat ownership, mismatched startup paths, no persistent save, remote-only critical assets, and an expensive CRT pass.

The production plan is to finish Level 1 as the vertical slice, install a small campaign kernel, greybox each genre before ordering art, then reuse the Level 6 raycaster for Level 7. The six guaranteed Stem Keys unlock mapped layers in the separately authored Full Mix arrangement and open the finale. Six optional Signature Modules change routes, powers, context, recovery, and the 9 Bit fight without ever being required.

## Your next 30–45 minutes

1. Close PR #4 without merging it.
2. Attach/unpack this v4 pack in a new Codex task and run `prompts/NEXT_CODEX_PR.md` for PR #5.
3. Confirm the task starts from current `main`, never reads or uses PR #4, and keeps 146/4/4 plus the 211-second manual restart only inside the explicit Level 1 `legacy-compatibility` profile.
4. When the PR is ready, run the included Makko/browser route: locked intro finish/skip, existing music/rhythm comparison, pause/restart soak, and current loop boundary.
5. Mark PASS, PASS WITH NOTES, or FAIL with device/browser and exact reproduction before merge.

When starting that task, attach/unpack this v4 archive into the workspace and tell Codex its path, or first commit an owner-approved documentation subset. The prompt intentionally stops if the controlling pack is unavailable.

## Decisions that unlock immediate art/code

Reply in one message with:

- **Level 1 boss:** current purple boss = Program Director / current purple boss = different name / generate new boss.
- **Level 4:** approve Dr. Mario-style linked-pair patching / use a different Tetris-or-Dr.-Mario branch.
- **Current level order:** approve the recommended 2 Racer, 3 Contra, 4 Puzzle, 5 party RPG, 6 DOOM, 7 finale / provide changes.
- **Ending model:** one ending first / multiple outcomes by final choice / multiple outcomes by lore + choice.
- **Target:** desktop keyboard+gamepad first / desktop+touch from the beginning.
- **Community:** which aliases may receive portraits, dialogue, voices, music, or functional assists; ambient text/signage needs no likeness.
- **Wulfspace spelling** and exact NUL.TV crossover boundary.

No decision above blocks music-profile PR #5, lifecycle PR #6, or enemy cleanup PR #7.

## Asset help available now

Current Makko proof is strong for JSON+WebP sprite animation, named animations, frame timing, anchors, hitboxes, scale, flip, alpha, hosting, and project smoke tests. It does not prove tilemaps, road rendering, raycasting, save systems, dialogue authoring, or full scene construction; Codex should build those.

Once a greybox fixes camera scale and hitboxes, the next asset cards should be:

1. 6 Bit attack/hurt/defeat readability;
2. eight Level 1 modular props and collision silhouettes;
3. boss fit/new art after your decision;
4. only then, small greybox-specific orders for the other genres.

The current flying-car GIFs need optimization, especially the ~21.2 MB third ship. Preserve originals and compare resized Animated WebP/video/fallbacks before switching.

## What not to spend time on yet

- dozens of Pokemon-style creatures;
- final Level 7 art before the raycaster and item-door proof;
- replacing approved intro or Level 1 art;
- lore prose before the 28 reveal purposes are approved;
- polishing random Level 1 kills that the authored stage will remove;
- adding movement abilities to solve stage-layout problems.

## Definition of the next major stride

The first milestone is not “seven incomplete modes.” It is the stable foundation through PR #10: per-level music profiles, correct lifecycle, input, enemies, authored Level 1 stage, versioned save, adapter teardown, and proof that one prior-level module changes a Level 7 door. PR #11 then completes Level 1 with its approved boss, fixed collectibles, rewards, result, and save handoff. From there, the risk is controlled genre/content production—not architectural collapse.
