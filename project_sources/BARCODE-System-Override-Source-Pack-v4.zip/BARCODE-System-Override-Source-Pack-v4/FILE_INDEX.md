# File Index

## Control surface

- `README.md`: entry point and campaign summary.
- `PROJECT_INSTRUCTIONS.md`: non-negotiable content/engineering rules.
- `DECISION_REGISTER.md`: locked, working, open, and superseded decisions.
- `CURRENT_STATE.md`: truthful live-project baseline.
- `SOURCE_MANIFEST.json`: audited commit/PR/campaign machine summary.
- `SUPERSESSION_LOG.md`: what v4 retains and replaces from v3, v2, and rejected branch drift.
- `AGENTS.md`: operating rules for Codex/Makko collaborators.
- `CHANGELOG.md`: v4 delta plus retained v3 history.

## Design and audit

- `docs/00_SOURCE_AND_PROVENANCE.md` through `docs/16_LOCKED_INTRO_RUNTIME_MAP.md`: vision, canon, campaign, finale, rhythm, repository audit, runtime/performance, Makko/assets, community, roadmap, QA, open decisions, traceability, legacy-lore quarantine, and exact intro runtime evidence.
- `levels/01_DEAD_AIR_DISTRICT.md` through `levels/07_NEGATIVE_SPACE.md`: one production brief per level.

## Machine-readable authority

- `data/campaign.json`: seven levels, genres, characters, rewards, lore IDs, adapters.
- `data/items.json`: six guaranteed Stem Keys and six optional Signature Modules with bounded Level 7 effects.
- `data/lore-plan.json`: 28 deterministic IDs and reveal/placement purposes.
- `data/easter-eggs.json`: stable alias IDs, tiers, level hints, approval states, and fallbacks.
- `data/music-cue-plan.json`: per-level cue families and separate finale Full Mix requirements.

## Engineering handoff

- `engineering/LEVEL1_VERTICAL_SLICE_BLUEPRINT.md`: normalized layout, encounters, cues, Jammer, boss, and acceptance route.
- `engineering/LEVEL_ADAPTER_CONTRACT.md`: lifecycle/context/registry/result contract.
- `engineering/MUSIC_PROFILE_CONTRACT.md`: distinct per-level song/profile, optional timeline, session, cue, and finale-layer rules.
- `engineering/SAVE_SCHEMA.md`: single-slot versioned save, backup/recovery, items, lore, settings.
- `engineering/PERFORMANCE_BUDGETS.md`: measurable budgets/instrumentation.
- `prompts/NEXT_CODEX_PR.md`: ready-to-run PR #5 replacement fixed music-profile/transport prompt from current `main`.
- `prompts/NEXT_FIVE_PRS.md`: scoped cards for PRs #5–#9 plus PR #10 and #11 handoff.
- `owner/OWNER_PACKET.md`: short decision and runtime-test handoff.

## Assets, production, and QA

- `assets/ASSET_REGISTRY.json`: verified audit inventory, hashes where measured, exact manifest mirrors, and production gaps.
- `assets/ASSET_NEEDS_BY_LEVEL.csv`: priority/order/dependency matrix.
- `templates/`: asset, cameo, playtest, and PR cards.
- `visuals/`: Level 1, locked-intro, and partial-sprite audit sheets.
- `references/`: audited repo manifest snapshots, repository audit snapshot, and byte-identical superseded v3/v2 archives.

## Validation

- `package.json` / `tools/validate-pack.mjs`: run `npm test` inside the unpacked folder.
- `FILE_HASHES.sha256`: generated last; verifies every other file in the source pack.
