# Reference Material

`BARCODE-System-Override-Source-Pack-v3-SUPERSEDED.zip` is retained byte-for-byte for immediate provenance. Its SHA-256 is `a465dd37be6b7a6b9766f94f0fadc7c34ca061624dd06a1151f2000804799078`.

`BARCODE-System-Override-Source-Pack-v2-SUPERSEDED.zip` is also retained byte-for-byte. Its SHA-256 is `5fe76d38bd6d354926627ce72285efe7c307040d2d8cfe8424fb97605648d2b9`.

Do not treat either nested archive as current instructions. v4 retains their approved canon locks and audit evidence where recorded while superseding v3's PR #4 dependencies and music-clock assumptions plus v2's cleanup-only scope, generic level scaffold, and completed prompt.

`REPOSITORY_AUDIT_SNAPSHOT.json` records the exact live source state used for this overhaul, including the rejected branch as provenance. Re-audit before implementation if GitHub `main` moves. PR #4 must remain outside `main`.
