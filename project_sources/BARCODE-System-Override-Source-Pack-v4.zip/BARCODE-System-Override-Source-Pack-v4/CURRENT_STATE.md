# Current State — 2026-07-15

## GitHub truth

- Repository: `6-Bit-01/BARCODE-SYSTEM-OVERRIDE`
- Public default branch: `main`
- Audited main: `29366454d6cebbd8aca65321e5b191fd88e43e88`
- Merged PR #1: truthful baseline and validation tooling
- Merged PR #2: startup lifecycle single-flight and leak reduction
- Merged PR #3: single-owner frame simulation
- PR #4 head: `5fc8ceb3d38be3fa1f9d2447a8ab15982394af94`
- PR #4 was still open at the final read-only audit, but the owner rejected it and will close it without merge.
- PR #4 is not design authority, is not a prerequisite, and must not be copied or stacked into future work.

Audited `main` passed its dependency-free test and syntax suites. These are static/unit checks, not hosted gameplay verification. PR #4's passing tests are retained only as rejected-branch provenance.

## What exists

- title/boot presentation;
- locked 11-image intro sequence;
- one flat 4,096-pixel Level 1 playfield;
- 6 Bit movement/sprite integration;
- Virus, Corrupted, Firewall, jammer, and old sector-boss art;
- rhythm mode and radial attack effects;
- hacking prototype;
- tutorial, objective, lost-data, lore, particle, parallax, flying-car, audio, UI, fullscreen, update, and render systems;
- validation scripts and GitHub CI.

## What does not exist

- a completed authored Level 1;
- normal always-available combat;
- platforms, collision map, compact arenas, authored landmarks, checkpoints, or a real boss transition;
- campaign router/channel select;
- Levels 2–7;
- save persistence or migrations;
- level-owned music profiles or a transport that can follow different songs, tempo maps, meters, offsets, loops, and cue maps;
- inventory/items/doors/skills;
- final victory/endings;
- DJ Floppydisc, Cache Back, or Mac Modem playable assets/logic;
- a local/offline production asset set;
- browser smoke automation that can run without Makko's missing host runtime.

## Immediate blockers to feature scaling

1. Existing Level 1 rhythm/audio code hardcodes timing in multiple files and cannot be the authority for six other songs.
2. Initial Start and restart use different initialization ownership.
3. Pause, audio, timers, and game state are not one coherent lifecycle.
4. Two active enemy definitions plus late patches create composite behavior.
5. Level 1 progression is still “kill 20, then destroy jammer.”
6. Combat only damages on narrow beat timing and currently applies successful rhythm damage twice.
7. No persistent campaign state exists.
8. Full-frame JavaScript CRT processing and large animated GIFs create avoidable performance risk.

## Current Level 1 art reality

The far BG is `1280×855`; the transparent street FG is `1279×462`. They have different aspect ratios but the renderer forces both into the same oversized rectangle, distorting the BG. Three approved flying-car GIFs total roughly 60.5 MB with the other downloaded Postimg assets; the GIFs alone are approximately 34 MB and contain 81/122/122 frames. The street is visually a flat sidewalk. Real platforming therefore needs additive readable props/collision overlays rather than invisible platforms.
