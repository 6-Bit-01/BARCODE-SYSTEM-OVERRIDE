# Locked Intro Runtime Map

Authority at audit: repository `src/engine/cutscene.js` at main commit `29366454d6cebbd8aca65321e5b191fd88e43e88`, checked against the visual contact sheet. Preserve the approved images and first eleven displayed subtitle records. Do not insert, redraw, reorder, or silently repair.

| Runtime index | Image entry | Displayed subtitle |
|---:|---|---|
| 1 | SO1 | “BARCODE Network… offline. Signal integrity at 0%.” |
| 2 | SO2 | “Unstable frequencies detected. Unknown interference rising…” |
| 3 | SO3 | “…hello? Why is everything so loud?” |
| 4 | SO4 | “Memory blocks corrupted. Systems rebooting against my will—” |
| 5 | SO5 | “Warning. Unauthorized access. Something is forcing the signal open…” |
| 6 | SO6 | “Control room integrity failing. Broadcast collapse imminent.” |
| 7 | SO7 | “If you're hearing this… something went wrong. The tower isn't safe anymore.” |
| 8 | SO8 | Mac Modem: “The network's alive, 6. And it's scared.” |
| 9 | SO8 (second current reference) | Cache Back: “We locked memories inside the system. Protect them.” |
| 10 | SO8 (third current reference) | Miss Bit: “You're our last broadcast. Do not screw this up.” |
| 11 | SO10 | “…Alright. If the system won't save itself—I will.” |

The source contains a **twelfth subtitle with no twelfth image entry**: “6 Bit vs 9 Bit — The fate of the BARCODE Network hangs in the balance…” It is unreachable in the audited sequence and conflicts with the explicit direction not to add 9 Bit to the locked prologue. Do not activate it. If code cleanup touches this mismatch, preserve runtime presentation and ask the owner whether to archive the unreachable line in a separate, narrow change.

The table normalizes line breaks and omits the dynamic HTML span around the signal-integrity number; it does not authorize copy edits. The exact runtime punctuation/markup remains in the cited repository file.

