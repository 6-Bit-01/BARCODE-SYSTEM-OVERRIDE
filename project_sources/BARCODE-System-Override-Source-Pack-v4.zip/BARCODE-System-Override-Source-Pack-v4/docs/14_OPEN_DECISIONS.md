# Open Decisions

These do not block PR #4 closure, the replacement profile/transport PR, or the lifecycle/enemy/combat cleanup sequence.

## Needed before Level 1 boss art

- Does the existing purple sector-boss art fit **The Program Director**, a different identity, or no approved identity?
- Is a new boss sprite required?

## Needed before genre asset orders

- Explicit owner approval or changes to the recommended level order/spotlights.
- Final display titles and exact independent level tracks.
- For each track: verified tempo/tempo map or marker-only decision, meter map, downbeat offset, sections/cues, stems, loop/end policy, and any optional judgment rules.
- Final Level 2 vehicle/road visual direction.
- Final Level 3 lead presentation and weapon-overlay strategy.
- Confirmation of linked-pair matching for Level 4.
- Level 5 Sample/rogue-program art count cap.
- Level 7 combat cadence: real-time with RPG commands, pause/slow-time command selection, or turn-based encounters inside first-person exploration.
- Approval/renaming of the working L2–L6 bosses: Tollkeeper, EULA-88, Memory Leak, Curator, and Root Daemon.
- Minimum device and controller/touch targets.

## Needed before Easter-egg story/functional production

- Which transformed echoes are approved specifically for this game?
- Which people approve portrait/likeness, voice, music, or functional-support use?
- Final spelling for Wulfspace Relay.
- NUL.TV/Willy the Warg exact crossover boundary.

## Needed before ending implementation

- Whether endings are choices, lore thresholds, or both.
- Canon outcome for 9 Bit.
- Who initiated the extraction process and how explicitly the game answers it.
- Whether the simulation is shut down, reclaimed, or remains active after the broadcast returns.
