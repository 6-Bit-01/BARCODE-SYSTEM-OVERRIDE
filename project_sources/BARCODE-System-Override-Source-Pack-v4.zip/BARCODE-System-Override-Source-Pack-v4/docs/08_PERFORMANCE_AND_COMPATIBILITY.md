# Performance and Compatibility

## P0 optimization work

1. Replace full-frame 1920×1080 JavaScript pixel post-processing with CSS/compositor effects or an optional low-resolution offscreen pass.
2. Use smoothing selectively: background art may smooth; pixel sprites/UI should remain crisp.
3. Stop stretching BG and FG to one rectangle. Compute aspect-correct dimensions and crop/travel deliberately.
4. Convert or locally optimize the three large flying-car GIFs after Makko/browser compatibility testing. Animated WebP or tracked video can reduce transfer/decode cost; keep a fallback.
5. Replace indefinite 100ms Makko sprite polling with one bounded asset service and visible failure state.
6. Remove HEAD-then-GET duplication where normal GET/error handling is sufficient.
7. Replace main-thread 30–60 second generated audio fallbacks with small prebuilt fallbacks or silence.
8. Dispose flying-car timers, jammer audio, intervals, sources, and listeners on pause/restart/level exit.
9. Gate debug logs and remove production bypass keys.
10. Use one world/ground coordinate source instead of physics `750`, render `890`, and scattered magic constants.

## Budgets

- target 60 FPS; never below stable 30 FPS on minimum target;
- simulation delta capped and fixed-step where genre behavior needs determinism;
- no per-frame full-canvas readback in normal mode;
- no unbounded particle/enemy/projectile/DOM collections;
- zero unowned intervals/timeouts after a level exits;
- level-start critical assets preloaded; optional assets lazy-loaded with bounded timeouts;
- first interactive frame should not wait on every noncritical remote file;
- save writes at checkpoints/results/settings changes, not every frame;
- cap device-pixel-ratio strategy after measuring; do not multiply a 1920×1080 canvas blindly.

## Responsive/accessibility compatibility

Remove `user-scalable=no`; scale the internal render safely; preserve readable UI zones; support keyboard and gamepad parity; add remapping and controller glyphs; define touch scope explicitly. Provide reduced flash/glitch, shake, bob, foreground flyby, and motion settings.

## Asset resilience

Remote Makko/Postimg/Supabase URLs are not a durable production archive. Maintain owner-controlled local backups and hashes. A production build should prefer first-party versioned assets with remote sources recorded as provenance, not as the only copy.

