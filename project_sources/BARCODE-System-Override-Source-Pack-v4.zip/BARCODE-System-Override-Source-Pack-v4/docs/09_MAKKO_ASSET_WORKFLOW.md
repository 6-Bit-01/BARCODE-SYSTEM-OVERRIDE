# Makko and Asset Workflow

## Capabilities proven by the current project

The repository demonstrates that Makko can:

- initialize a sprite manifest through `MakkoEngine.init`;
- expose characters and named animations;
- load JSON + WebP animation exports;
- play/stop/update/draw sprite animation;
- report animation/frame information and world hitboxes;
- draw with scale, flip, and alpha options;
- host exported sprite-sheet and audio assets;
- act as the owner's visual/runtime test surface.

The current manifest proves 12 FPS animation exports with dimensions, frame counts, duration, anchors, and bottom-center placement metadata. Makko also parses every `.js` file in the synced project, loaded or not.

## Capabilities not proven by this repo

Do not assume Makko supplies tilemap authoring, pseudo-3D road construction, raycasting, full 3D, dialogue tooling, save management, background outpainting, or an automated production asset pipeline. Codex should implement those systems unless the owner confirms a Makko feature.

## Best division of labor

### Makko

- final character/enemy/boss sprite animation;
- anchors, frame timing, hitbox/scale checks;
- duplicate-project import and smoke testing;
- stable asset export/hosting.

### OpenArt / image generation

- concept sheets;
- backgrounds, tiles, props, wall textures, posters, signage, portraits;
- horizontal expansion of the existing Level 1 BG if the aspect-correct crop is insufficient;
- ingredient-based iteration when one-shot generation misunderstands the asset.

### Codex

- greybox mechanics and collision before art orders;
- exact asset request cards and naming;
- manifests, registries, cue sheets, compression/local fallback wiring;
- code-native UI, puzzle symbols, procedural placeholder geometry;
- automated dimension/anchor/path/hash validation;
- integration and PRs.

## Asset cycle

1. Greybox the camera, scale, collision, and timing.
2. Approve an asset card with ID, use, dimensions, animation list, FPS, anchor, hitbox, palette/style, and fallback.
3. Generate/create in the appropriate tool.
4. Export under a stable filename/ID.
5. Preserve the original source/export.
6. Record remote URL, local path, dimensions, frame data, source, approval, credit/rights, and hash.
7. Commit asset/registry changes separately from unrelated gameplay.
8. Integrate by stable ID.
9. Test in a duplicate Makko project for scale, alpha, animation, anchor, collision, performance, pause, and restart.
10. Mark approved only after owner PASS/PASS WITH NOTES.

## Sprite export guidance

- preserve transparent backgrounds;
- keep a consistent ground/contact point;
- avoid generating enormous frames for small on-screen characters;
- prefer readable anticipation/contact/recovery over excessive frame count;
- billboard FPS enemies need front-facing animations, not eight-angle sheets, unless the design proves otherwise;
- use separate weapon/FX overlays when they prevent a combinatorial animation explosion;
- never describe or redesign 6 Bit's appearance when the approved reference/export can be used directly.

