# Roadmap and PR Ledger

## Foundation and rejected branch

| PR | Status | Result |
|---|---|---|
| #1 | merged | truthful baseline, validation, CI, Makko-safe archive |
| #2 | merged | startup single-flight and retry lifecycle improvements |
| #3 | merged | single-owner frame simulation/update/render |
| #4 | owner-rejected; close unmerged | fixed Level 1 clock branch; tests are provenance only and no code is reused |

## Immediate five PRs from current main

### PR #5 — level-aware music profiles and transport

Build fresh from `main`. Add immutable level-owned profile data and one active fixed transport/session anchored to Web Audio start. Preserve current Level 1 behavior through the explicit `legacy-compatibility` profile. Prove different fixed tempos, meters, grid origins, and playback policies plus no-grid judgment-unavailable behavior. Defer tempo/meter changes, live cue delivery, and seek until approved content requires them. Remove configuration literals from active audio/rhythm/cutscene/debug paths. Do not create other levels or inspect/reuse PR #4.

### PR #6 — one startup/pause/runtime lifecycle

Route first Start, retry, and restart through one initializer; add one pause/state owner; suspend/resume the loop, active music session, mixer, and level scope; dispose owned resources; keep presentation/gameplay unchanged.

### PR #7 — one enemy system and non-enemy jammer

Consolidate `enemies.js`, `jammer-fix-patch.js`, spawn patch, and collision patch into one owner. Fix double integration/timer units/collision NaN/abort behavior. Recast Jammer as an environment trigger. Preserve current enemy art and approximate feel pending Level 1 tuning.

### PR #8 — 6 Bit combat contract and action input

Introduce semantic actions; remove production debug bindings and dead dash/fast-fall/stomp drift; normal attack always works; Level 1 timing judgment adds bounded bonuses; remove double damage; rewrite the tutorial only as needed for approved controls.

### PR #9 — authored Level 1 stage/parallax/traffic

Add the data-driven five-part layout, readable props/platform collisions, arena/milestone gates, checkpoints, aspect-correct BG/FG rendering, and Level 1 profile-cue traffic choreography with readable degraded-audio fallbacks. Remove kill quota and random endless flow.

## Level 1 completion and production foundation

### PR #10 — campaign kernel and versioned save

Add `GameApp`, `LevelDirector`, Level Adapter registration, `CampaignStore`, versioned save/backup/recovery, `DisposableScope`, channel/results boundary, and promote the existing shared `ActionInput` and music-profile service. Wrap Level 1 without redesigning it. Prove one stable Level 1 item flag changes a development-only Level 7 door and no optional flag blocks the main route.

Internal checkpoints are registry/adapter teardown, save/backup/recovery, then UI/item-door proof. If reviewable implementation cannot stay focused, split the last UI/proof portion into a follow-up rather than shipping one oversized PR.

### PR #11 — Level 1 boss and vertical-slice completion

Implement the owner-approved boss identity, natural transition, three fixed Lost Data pieces, Voice Stem Key, optional Beat Anchor, result/save handoff through PR #10's store, and the full owner test route.

### PR #12 — asset registry/preloader and production optimization

Stable asset IDs, bounded preload, local/remote fallback, production log/debug modes, CRT optimization, ship timer disposal, and asset QA.

## Genre production order

Risk-driven prototype order:

1. Level 4 grid puzzle greybox;
2. Level 2 racer greybox;
3. Level 3 run-and-gun greybox;
4. Level 5 party RPG vertical slice;
5. Level 6 raycast foundation and level;
6. Level 7 hub/module-door proof, full exploration, then 9 Bit boss;
7. whole-campaign accessibility, performance, Easter eggs, endings, and content QA.

Numerical shipping order remains 1→7; prototype order is about reducing risk before expensive assets.
