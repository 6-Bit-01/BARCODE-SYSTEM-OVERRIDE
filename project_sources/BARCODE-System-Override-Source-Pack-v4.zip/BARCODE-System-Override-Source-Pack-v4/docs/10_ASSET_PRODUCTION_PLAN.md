# Asset Production Plan

## Production rule

Every genre gets a five-minute playable greybox before a large art order. The greybox must prove camera, controls, collision, one enemy/obstacle, one musical interaction, pause, teardown, and save-return. “Musical interaction” may be adaptive layers, section/setpiece cues, arrangement changes, or optional input judgment; it does not require a beat test.

## Level 1 — reuse first

Reuse title/intro, BG, FG, ships, 6 Bit, Virus, Corrupted, Firewall, jammer presentation, particles, audio, UI, and old sector-boss asset pending identity approval.

New minimum set:

- 6 Bit readable attack/hurt/defeat solution;
- enemy hit/defeat and musical telegraph overlays;
- 6–10 modular street/platform props: awnings, crates, speaker stacks, bus shelter, scaffold, cables, signs, dumpsters;
- hazard/arena boundaries readable against FG;
- boss identity/art only if existing sector boss does not fit;
- optional aspect-correct BG horizontal expansion after crop prototype.

## Level 2 — racer

- Cache Back driver portrait/reactions;
- player signal vehicle rear/turn/damage/boost;
- 5–7 traffic vehicles;
- road/rail segments, horizon layers, signs, forks, obstacles, checkpoint gates;
- Tollkeeper phase assets;
- HUD icons and route map.

## Level 3 — run-and-gun

- 6 Bit or modular weapon overlays for run/jump/crouch/aim/fire/hurt/defeat;
- 4 enemy families and one miniboss;
- destructible emplacements/bridge/lift props;
- weapon/projectile pickups with original BARCODE silhouettes;
- EULA-88 boss states.

## Level 4 — puzzle

- DJ Floppydisc operator portrait/reactions;
- Patch Plug pairs;
- malware packet symbols with color + shape/pattern;
- Memory Leak states;
- code-native grid, preview, cascade, score, accessibility, and remix UI.

## Level 5 — party RPG

Highest content load:

- four overworld crew sets and four compact battle sets;
- one settlement, two routes, one cave/underground space, one tower interior tileset;
- 6–8 rogue-program/Sample families;
- 8–12 reusable NPC bases/portraits;
- party/menu/status/Sample icons;
- Curator boss/filter states.

Do not create dozens of creatures before one town-route-battle loop is fun.

## Level 6 — raycast FPS

- Mac Modem HUD/hands/weapon overlays;
- 4–5 front-facing billboard enemy families;
- 3–4 weapon/ability overlays;
- 64/128px wall, door, switch, floor/ceiling textures;
- pickups and frequency keys;
- Root Daemon boss;
- limited portraits/assist effects for the other three.

## Level 7 — first-person RPG finale

Reuse the Level 6 renderer, navigation, walls, doors, pickups, and appropriate enemies. Add:

- hub/wing textures and archive displays;
- six module icons and door states;
- four leader portraits/hand/ability overlays;
- party/inventory/map/dialogue UI;
- 9 Bit multi-phase art and FX;
- extraction logs, memory-theater visuals, and owner-approved ending presentation.

## Cost-control priority

Prototype Level 4 first after the campaign kernel because it is mostly code-native. Prototype Level 6 raycasting before Level 7 content. Level 5 should be content-capped deliberately; it is the easiest level to let balloon.
