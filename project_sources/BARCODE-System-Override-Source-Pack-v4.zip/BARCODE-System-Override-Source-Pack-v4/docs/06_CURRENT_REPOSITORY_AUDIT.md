# Current Repository Audit

## Headline

The repo has a stable static-validation foundation and three valuable merged cleanup PRs, but Level 1 is still a prototype sandbox and the runtime is not ready to host six more genres directly.

## Scale and structure

- 35 active repository JavaScript files plus two inline scripts;
- roughly 23,728 active JavaScript lines;
- roughly 6,903 unloaded/diagnostic/legacy JavaScript lines;
- browser globals and direct script order; no modules/bundler/dependencies;
- fixed 1920×1080 canvas;
- `index.html` is entrypoint;
- `/lib/MakkoEngine.min.js` is required but absent from Git.

Largest active files include `audio.js` (~2,964 lines), `rhythm.js` (~2,330), `player.js` (~1,960), `jammer-fix-patch.js` (~1,782), and `enemies.js` (~1,733). The full repo includes about 1,440 console calls, 142 `setTimeout` calls, 12 `setInterval` calls, and 94 `Date.now` occurrences across source/index/patch surfaces.

## What PRs #1–#3 fixed

- truthful baseline/inventory/CI;
- Makko parser-safe archiving of inactive syntax failures;
- startup single-flight and retry timeout ownership;
- one authoritative gameplay RAF/update/render owner;
- debug gating for previously noisy frame logs.

PR #4 is not part of this foundation. It remained unmerged at audit and the owner rejected it; future timing work starts fresh from `main`.

## Critical remaining runtime defects

### Startup split

First Start manually initializes systems in `index.html` and does not call the same full initializer used by restart. `sector1Progression` can therefore be absent on first run but present after restart. Several systems also auto-initialize on DOM ready. Make one lifecycle owner.

### Enemy composite

`src/game/enemies.js` and `jammer-fix-patch.js` both define the same globals and construct managers; later files then replace spawn and collision methods. Current behavior is a load-order composite. Consolidate before tuning.

Concrete risks include double position integration, seconds-vs-milliseconds timers, collision early return on jammer pairs, divide-by-zero on exact overlap, unsafe multiplicative speed timeouts, orphaned jammer HTML Audio, and missing disposal.

### Music timing split

`src/engine/audio.js` hardcodes three Level 1 source IDs, a 211-second restart, `60 / 146` beat math, and recursive timer scheduling. `src/game/rhythm.js` separately hardcodes 146 BPM, four-beat bars, and four-bar phrases while measuring against a different time domain. Multiple `src/engine/cutscene.js` completion/fallback paths call `startBackgroundRhythm(146)` after music startup. There is no gameplay-song profile registry.

This cannot scale into seven different songs. Move the existing Level 1 values into an explicitly provisional Level 1 profile, anchor one active transport/session to the actual Web Audio source start, and prove profiles with different timing—or no grid—without inventing other levels' music metadata.

### Combat contradiction

Current Down attack only damages inside narrow timing windows and is disabled outside R mode. Successful rhythm input applies attack checking in both `rhythm.js` and `input.js`, causing likely double damage. Stomp can deal 999 damage and grants invulnerability. Dash remains bound/advertised but immediately returns.

### Progress/save contradiction

Progress is RAM-only. `initGameState()` resets the values `startNewGame()` later attempts to restore. Kill totals can double/triple count across state, manager, and sector objects. `maxLevel` is 5. There is no campaign unlock, item, checkpoint, door, ability, ending, or victory schema.

### Pause contradiction

`window.isPaused` and `gameState.paused` compete. P changes only one state; audio/timers may continue. Levels need a shared pause lifecycle.

## Level 1 divergence

Approved design calls for traversal, compact arenas, always-functional attacks, beat bonuses, musical telegraphs, authored milestones, non-enemy jammer, and a boss transition. Current play is a flat 4,096-pixel endless random enemy flow, kill-20 gate, destroyable jammer, no platform/collision layout, no boss, and an empty transition block.

## Content risks

`lost-data.js` contains 95 repetitive/speculative entries and `lore.js` contains 46 short messages. Many define origins or 9 Bit behavior beyond approved canon. Curate 28 authored pieces into data before shipping.

## Static validation gaps that remain expected

- missing `/lib/MakkoEngine.min.js`;
- missing local whoosh fallbacks;
- stale `final-verification-test.js` reference to an absent enhanced jammer file;
- duplicate active enemy globals;
- remote-asset reachability not proven by static host inventory.
