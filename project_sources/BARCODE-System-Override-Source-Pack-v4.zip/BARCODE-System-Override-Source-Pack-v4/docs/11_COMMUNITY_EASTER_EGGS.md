# Community Easter Eggs and Cameos

## Permission tiers

1. **Ambient echo:** transformed handle on signs, posters, serials, graffiti, routes, score tables, or terminals. No real name, likeness, voice, music, or negative claim.
2. **Story cameo:** dialogue, portrait, recurring NPC, recognizable likeness, or authored lore. Record approval and a removable fallback.
3. **Functional support:** assist, buff, item, voice, music excerpt, or plot effect. Requires explicit approval and credit/rights records.

No collaborator/community member becomes a villain, monster, kill target, humiliating joke, or capturable creature without explicit enthusiastic approval. No real personal names. Do not use “Brownout.” Call’em Bini/Bini is already represented by Cache Back; do not add a separate Bini egg.

## Density target

Per level:

- 3–5 ambient echoes;
- the authored Lost Data count for that level;
- one hidden Studio Rat;
- one NUL.TV/Dead Channel transmission;
- no more than one major functional cameo unless the level genuinely needs it.

This produces 40+ discoveries without making the main playfield unreadable.

## Suggested placement bank

| Echo | Level/use |
|---|---|
| Mister N1CE Guide | L5 route guide terminal; L7 welcome/status kiosk |
| EMRLD Channel | L1 station billboard; recurring green frequency |
| Melancholy Heartware + August Heatglass | paired L4 patch programs; L7 archive entry |
| NUL.TV / Dead Channel | one hidden transmission per level; separate feed |
| Dr3wB4by Blue | L2 vehicle/decal; L5 recovery screen/poster |
| W3T TDDY Transmission | guaranteed ally route reveal; Tower access support |
| SKELLA Choir | L4 cascade sting; L5/L7 chorus transmission |
| Tonal Oracle | L4 analysis prompt; L5 mentor terminal |
| Wulfspace Relay | L2/L6 relay sign; spelling requires final owner lock |
| The Freeboot Signal | pirate checkpoint/channel in L2/L3 |
| Galaknoise Weather | L2 road-weather service; L6 storm status feed |
| Chino-Seventy-Four | L2 service bay; L5 vendor serial |
| MUTE-E-L8R | L3 locker/sticker; L6 suppressor joke |
| Cruz Control | L2 tuning garage and route assist |
| Solo-So Echo | L5 station/performer echo; no controlled party slot |
| TIF.FY_B0MB | L3 demolition brand/poster; never a person used as a weapon |
| H3LLCAT Alley | L1 named upper-route side street |
| OREAGANOMIX | L4 remix preset; L5 sample shop/food stall |
| MZK-Queen Route | L2 exit sign; L5 map path |
| LoST M4RBLES | L4 score name and literal hidden-marble gag |
| Crowline | L1 rooftop graffiti; L2 courier/overpass line |
| Kaveman's Hollow | L5 venue/cave; L6 secret room |
| M1ND_FANATIC | L4 diagnostic signature; L7 architecture log |
| D34D1TE_ASH | L6/L7 riddle terminal; transformed handle only |
| Cliff | incorrect maintenance notes and accidental stage changes |
| Sheila | practical intercom/control presence; silhouette only if shown |
| BNL-01 | procedural status/liaison terminals; never omniscient exposition |
| Studio Rats | one hidden rat per level; all seven unlock gallery/music gag |

The machine-readable registry is `data/easter-eggs.json`. Story, likeness, voice, music, and functional-support approval must be recorded before production.

