# QA and Test Matrix

## Every PR

- Makko parses every `.js` file;
- `npm ci`;
- `npm test`;
- `npm run check:syntax:all`;
- `npm run audit:paths`;
- `npm run audit:globals`;
- `npm run audit:external-assets`;
- `git diff --check`;
- inspect changed asset dimensions/paths/anchors;
- owner duplicate-project Makko smoke test.

## Core runtime

Test first Start, rapid Start, failed load/retry, intro advance/hold-skip, gameplay entry, pause/resume, audio suspension, controller reconnect, game over, restart, level exit/reentry, and title return. Verify zero duplicated managers/listeners/timers/sources after each cycle.

## Campaign/save

- new profile;
- each checkpoint and level result;
- migration from every prior schema fixture;
- corrupted/partial save fallback;
- all six Stem Keys;
- every combination of optional modules;
- return to earlier levels before finale;
- no-module Level 7 completion;
- all-module Level 7 completion;
- collectible seen flags and duplicate prevention.

## Genre-specific

- L1: collision/routes/arenas/beat bonuses/boss/checkpoints;
- L2: steering, collision, hills/forks, checkpoint time, pause-safe traffic;
- L3: aim directions, projectiles, destructibles, enemy wave determinism;
- L4: rotation, clear detection, cascades, garbage, symbol accessibility;
- L5: turn order, party swap, status, Sample effects, save/reload mid-route;
- L6: raycast collision, doors/keys/secrets, projectile hits, map bounds;
- L7: module gates, party switch, every boss phase, point-of-no-return, endings.

## Accessibility

Test full remapping; keyboard/gamepad parity; per-profile timing calibration where enabled; visual timing lane only where relevant; reduced flash/shake/bob/flybys; subtitle sizes/backgrounds; color+shape puzzle symbols; racing assists; shooter assists; puzzle slow/no-pressure mode; pause outside technical transitions.

Music-session coverage must include seven distinct profiles, a no-grid song, a free-time intro, synthetic tempo and meter changes, authored seconds/marker cues, loop and non-loop end policies, optional-stem failure, autoplay denial, mute, pause/resume, seek/restart, hitch recovery, and switching levels without retaining the prior profile's timing or sources.

## Performance

Capture frame-time and memory at cold start, peak Level 1 particles/crowd, Level 2 traffic, Level 3 projectiles, Level 4 cascade, Level 5 menu/battle transition, Level 6 dense sightline, Level 7 hub and boss. Repeat restart/level transitions at least ten times to expose leaks.
