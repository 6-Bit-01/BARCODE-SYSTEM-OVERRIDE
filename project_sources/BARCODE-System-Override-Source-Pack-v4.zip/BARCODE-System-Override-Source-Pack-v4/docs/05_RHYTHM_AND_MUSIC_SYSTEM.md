# Rhythm and Music System

## Seven songs, seven timing profiles

Each level has a different gameplay song and owns an independent profile: asset ID, duration, grid origin, tempo or tempo map, meter or meter map, sections, markers, playback policy, sources/stems, cue map, and any judgment rules. Production capabilities require verified metadata; Level 1 temporarily uses the explicit `legacy-compatibility` status. No value is inherited from Level 1 and there is no default 146 BPM campaign clock.

PR #4 is rejected and must be closed without merge. Its `window.musicClock` implementation is not a prerequisite or source to copy. The next implementation PR builds the replacement profile/transport seam fresh from current `main`; lifecycle unification follows against that explicit music-session boundary.

One shared audio service may own the currently active `MusicSession`; the active Level Adapter supplies the profile and consumes named cues. This avoids competing timers without pretending all songs share one musical grid. Unknown metadata stays disabled/unverified rather than receiving a guessed BPM.

The six campaign Stem Keys are narrative/progression IDs. Level 7's audible Full Mix must be a separately produced compatible six-stem arrangement—or an approved premix with bounded alternates—with its own Level 7 profile. Never overlay the unrelated level songs.

## Genre expression

| Level | Musical advantage | Always works without timing judgment |
|---|---|---|
| 1 | verified timing can add damage, stagger, combo, recovery, and telegraph clarity | movement/basic attack |
| 2 | authored cues can shape boosts, traffic, and route changes | steering/acceleration/braking |
| 3 | track sections can shape heat, reload/burst bonuses, and waves | movement/aim/fire |
| 4 | clears/cascades remix layers; pressure may follow this song's sections | rotate/drop/clear |
| 5 | move flourishes and Samples alter the active arrangement | selected turn action |
| 6 | cues may improve reload/alt-fire efficiency and enemy readability | fire/navigation |
| 7 | its separate Full Mix profile drives party/module/boss cues | normal RPG actions/main route |

## Accessibility/calibration

- visual timing lane or cue pulse only where the active level uses it;
- per-profile audio/video input-offset calibration where judgment is enabled;
- controller vibration toggle;
- configurable windows by difficulty/assist;
- reduced flash/shake;
- no punishment that blocks story progress because a player cannot hit tight timing.

## Current audio debt

The Level 1 stems do not have matching lengths: foundation and FX are about `212.088s`; bass is about `210.442s`; the runtime restarts at `211s`. Re-export matched stems or provide explicit musical loop endpoints before final timing polish. No BPM or downbeat has been owner-verified for this pack. Current fallback generation can allocate tens of megabytes and loop millions of samples on the main thread; replace it with small prebuilt fallback assets or silence plus a visible degraded state.
