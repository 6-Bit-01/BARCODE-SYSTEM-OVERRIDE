# Meta Progression and Finale

## Stable campaign IDs

Guaranteed Stem Key IDs:

- `stem.voice`
- `stem.bass`
- `stem.drums`
- `stem.synth`
- `stem.samples`
- `stem.noise_fx`

Optional modules:

- `module.beat_anchor`
- `module.phase_capacitor`
- `module.breach_emitter`
- `module.restore_point`
- `module.crew_link`
- `module.root_credential`

Levels save these IDs, not instances of game objects.

These IDs unlock six compatible layers in the separately authored Level 7 Full Mix. They are not the seven independent gameplay songs and never cause those songs to be overlaid.

W3T TDDY's guaranteed ally credential reveals and presents the Tower route once the Full Mix is complete. It is story support, not a seventh item gate and not a collectible the player can miss.

## Level 7 dependency matrix

| Source | Module | Door/wing | Exploration benefit | 9 Bit benefit |
|---|---|---|---|---|
| L1 | Beat Anchor | Broadcast Archives resonance lock | reveals decoys/hidden audio; one cadence guard per combat room | marks true Reflection; first approved Level 7 cadence window each phase cancels one rush |
| L2 | Phase Capacitor | Transit lift | major shortcut and finale-only phase strafe | a correct strafe negates one lane sweep per phase |
| L3 | Breach Emitter | Armory bulkhead | heavy tool, armor cache, cracked barriers | breaks Anger armor early |
| L4 | Restore Point | Rollback Archive | one expedition-wide automatic party rollback | if unspent, cancels one Shame wipe |
| L5 | Crew Link | Memory Theater | deeper scenes and one extra assist/reaction charge per party member | one coordinated interrupt per Rejected Mix callback |
| L6 | Root Credential | Admin Control | full map + generator shutdown | removes one Rejected Mix arena hazard |

## Negative Space layout

- **Mixing Floor:** central hub; insert all six Stem Keys and activate the separate Full Mix layers.
- **Broadcast Archives:** Level 1 resonance wing.
- **Transit Bay:** Level 2 shortcut/phase systems.
- **Armory Bulkhead:** Level 3 offense/armor.
- **Rollback Archive:** Level 4 recovery and missing logs.
- **Memory Theater:** Level 5 crew/context scenes.
- **Admin Control:** Level 6 map and generator shutdown.
- **Negative Space:** preparation room, point-of-no-return warning, 9 Bit location and fight.

The player can return to Channel Select before the point of no return.

The mandatory Mixing Floor reconstruction and main descent provide every fact required to understand the confrontation. Memory Theater and the other module wings deepen or personalize that context; they never hold a required reveal hostage to an optional item.

## 9 Bit boss

### Phase 1 — Reflection

Level 7's own music profile can echo Level 1's bonus-window grammar while emotional patterns become Anger rushes, Fear barriers, Suspicion decoys, and Shame information loss. It does not reuse Level 1's song or timing map.

### Phase 2 — Rejected Mix

Compact callbacks to Levels 2–6: lane sweep, run-and-gun volleys, falling corruption zones, party turn marks, and a root-maze generator. Switch original-four roles to counter them.

### Phase 3 — Negative Feedback

A close first-person duel. Six compatible Full Mix layers return as readable powers; community/sample motifs enter last. Optional modules soften patterns, but skill always remains sufficient.

## Anti-softlock rules

- Stem Keys are guaranteed level-clear awards.
- Modules never occupy the only path to 9 Bit.
- Every locked door exposes its requirement in the map UI.
- The last pre-boss save remains loadable and allows return to Channel Select.
- Save migration treats unknown/missing optional IDs as false, never corrupt.
- Boss baseline is balanced for zero modules; modules are advantages, not assumed stats.
