# Source and Provenance

This pack was built from:

- the owner's current seven-level overhaul instruction;
- prior BARCODE GAME conversations and recovered project-specific decisions;
- the attached Source Pack v3 archive that v4 directly revises;
- the attached Source Pack v2 archive;
- a fresh read-only clone of `6-Bit-01/BARCODE-SYSTEM-OVERRIDE`;
- merged PR metadata and patches for PRs #1–#3;
- the open-at-audit PR #4 patch and checked-out head, retained only to document the branch the owner later rejected;
- static repository audits, exact file inspection, manifest inspection, asset downloads, image dimensions, frame counts, and visual contact sheets;
- successful test runs on `main` and the now-rejected PR #4 branch; branch tests do not make it implementation authority.

Decision-by-decision source mapping and the 141-string legacy lore quarantine are in `15_TRACEABILITY_AND_LEGACY_LORE_TRIAGE.md`. The exact audited intro image/subtitle mapping and unreachable twelfth line are in `16_LOCKED_INTRO_RUNTIME_MAP.md`. Raw private conversation transcripts are summarized into decisions rather than reproduced.

## Audited states

| Surface | Ref | Result |
|---|---|---|
| GitHub main | `29366454d6cebbd8aca65321e5b191fd88e43e88` | `npm test` and all-JS syntax pass |
| Rejected PR #4 | `5fc8ceb3d38be3fa1f9d2447a8ab15982394af94` | open at audit; full branch tests passed; owner directed close without merge or reuse |
| Source Pack v3 | SHA-256 `a465dd37…` | ZIP retained byte-for-byte; superseded by the owner's rejection of PR #4 and per-level music correction |
| Source Pack v2 | SHA-256 `5fe76d38…` | ZIP valid; 26 paths; no code/assets |

## Evidence labels used in this pack

- **Repository fact:** directly present in the audited files or GitHub state.
- **Runtime inference:** strongly implied by active control flow but not executed in Makko.
- **Owner lock:** direct current or recovered instruction.
- **Working design:** the chosen coherent plan, still adjustable where marked.
- **Open:** needs owner or asset/runtime evidence before final implementation.

## Limitations

`/lib/MakkoEngine.min.js` is referenced but absent from Git. A complete local browser launch cannot reproduce the hosted Makko environment without that file. External assets were inventoried; key Postimg visuals were downloaded and measured. Some Makko sprite endpoints were slow/unreachable from the audit environment, so the checked-in manifest remains metadata authority for those animations.
