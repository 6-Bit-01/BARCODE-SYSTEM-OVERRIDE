# Canon, Cast, and Simulation

## BARCODE and the Network

BARCODE began with 6 Bit, DJ Floppydisc, Cache Back, and Mac Modem. BARCODE Network came later as the apparatus around the signal. The Network did not create the crew and must not erase their identity as artists/performers by reducing them to software classes.

## Simulation premise

The intro drops 6 Bit into a recovery environment that claims BARCODE Network is collapsing. The environment rebuilds damaged sectors using archived cartridge logic. The crew initially treats the mission as live repair. Evidence gradually suggests that at least some voices and events are recordings assembled by the simulation, and that the sector architecture was built to contain evidence of a personality-separation process.

Who built the simulation and why remains intentionally unconfirmed until the finale is written. It may be a Network diagnostic, a containment tool, a recovery rehearsal, or something repurposed by 9 Bit. Do not answer that casually in filler lore.

## 9 Bit

**Locked core:** 9 Bit was created from negative/rejected parts separated from 6 Bit. He is part of 6 Bit's history, not a generic outside invader or an unrelated evil clone.

**Working thematic articulation:** anger, fear, insecurity, resentment, suspicion, shame, control hunger, and self-sabotage are candidate manifestations. Their isolation from humor, proportion, love, memory, accountability, creativity, and community explains the danger. The current boss concept has 9 Bit trying to overwrite 6 Bit and prove the rejected version is the only honest one. The owner must approve the exact trait list, motive, and final dialogue before they become canon.

Whatever final wording is approved, 9 Bit is responsible for active harm and must be confronted. The story must not imply that compassion requires surrendering to him, or that health means deleting every difficult emotion.

## Original four gameplay identities

| Character | Identity | Mechanical language |
|---|---|---|
| 6 Bit | host, artist, producer, emotional center | balanced flow, timing bonuses, direct action |
| DJ Floppydisc | tempo and waveform control | speed/turn order, buffs, silence, pattern control |
| Cache Back | archives, saved state, restoration | checkpoints, recovery, shields, rollback |
| Mac Modem | good virus, unstable access, risk/reward | infection, breach, heat, high-risk damage |

These identities guide genre adaptations; they are not a locked universal move list.

“Good virus” is Mac Modem's established character metaphor. It is not a label for 6 Bit, the player-avatar as a whole, or the BARCODE crew.

## Supporting cast

- **Miss Bit:** mission/teleoperator/transmitter presence; exact nature remains open.
- **BNL-01:** procedural liaison/status voice, not omniscient.
- **Sheila:** practical operations/control pressure; use voice, screens, or silhouette only where shown.
- **Cliff:** backstage/stagehand chaos and accidental maintenance failures.
- **Studio Rats:** environmental anomaly-creatures and recurring secrets.
- **W3T TDDY:** ally; provides guaranteed route revelation and helps present/open Tower access after the Full Mix is complete; never fights the player and never adds a missable campaign gate.
- **NUL.TV / Willy the Warg:** separate-canon dead-channel feed that can cross the signal as a transmission, not be absorbed into BARCODE canon.

## Prologue locks

The existing intro art and presentation stay. Core locked lines include:

- “The network's alive, 6. And it's scared.”
- “We locked memories inside the system. Protect them.”
- “If the system won't save itself—I will.”

The code currently has 11 image entries and 12 subtitles; the last subtitle is unreachable. Verify intent with the owner before any implementation-only correction. Do not use that mismatch as permission to rewrite the intro.
