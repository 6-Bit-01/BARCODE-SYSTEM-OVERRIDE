# Runtime Architecture

## Goal

Add a small campaign kernel around the revived runtime so each genre owns its simulation without fighting Level 1 globals.

## Shared services

- `GameApp`: boot/title/intro/channel-select/level/results/finale state machine.
- `LevelDirector`: loads one Level Adapter, owns transition and teardown.
- `CampaignStore`: versioned save, migrations, checkpoints, items, collectibles, settings.
- `ActionInput`: keyboard/gamepad/touch bindings mapped to semantic actions.
- `MusicSessionService`: owns one active playback session; validates the active level's distinct music profile and exposes only supported cues/judgments. It has no global BPM.
- `AssetService`: one bounded preload path with stable IDs and fallbacks.
- `AudioMixer`: music/SFX/voice buses, pause/suspend, tracked sources.
- `EventBus`: typed-ish campaign events, no direct cross-level object access.
- `DisposableScope`: timers/listeners/sources/DOM nodes cleaned on scene/level exit.
- `SettingsService`: accessibility, volume, calibration, controls, display.

## Level Adapter

Each level implements:

```js
{
  id,
  mode,
  preload(context),
  enter(context, checkpoint),
  handleAction(action, phase, value),
  update(deltaMs),
  render(frame),
  serializeCheckpoint(),
  pause(),
  resume(),
  exit()
}
```

`context` exposes shared services, not arbitrary globals. `context.music` is already bound to that adapter's declared `musicProfileId`; a level cannot load another level's timing data. `exit()` must leave zero level-owned listeners, intervals, timeouts, audio sources, DOM overlays, and animation loops.

## Genre cartridges

- `sideScroller2D`: Level 1 and selected Level 3 shared movement/collision primitives.
- `pseudo3DRacer`: Level 2.
- `runGun2D`: Level 3.
- `gridPuzzle`: Level 4.
- `topDownPartyRPG`: Level 5.
- `raycastFPS`: Level 6.
- `firstPersonPartyRPG`: Level 7, extending the Level 6 renderer/navigation while replacing its pacing and combat layer.

## Migration strategy

Do not rewrite everything before Level 1 improves. Wrap the existing Level 1 behind an adapter after its lifecycle/enemy/combat ownership is cleaned. Add the campaign kernel with a development cartridge that proves enter/update/render/exit/save-return. Then build one five-minute greybox per genre before ordering full assets.

## Namespacing

Because Makko compatibility discourages a sudden bundler rewrite, new code can use `window.BARCODE = window.BARCODE || {}` and attach services/modules under it. Avoid new unscoped globals and never redefine the same global from multiple loaded files.
