# Game Vision and Pillars

## Vision

**BARCODE: SYSTEM OVERRIDE** is a focused cyberpunk comedy/action campaign that behaves like a damaged multi-game cartridge transmitted through BARCODE Network. The authored main paths target roughly 2.1–2.7 hours; a normal first campaign with intermissions, exploration, optional modules, retries, and the finale should land near 3–4 hours. Every level changes genre, but the crew, signal, music, inventory, story, and consequences persist.

## Player promise

1. Every level genuinely plays differently.
2. Every reference is recognizable through mechanics, not stolen surface assets.
3. Music shapes play without turning every input into a rhythm-game fail state.
4. The original four matter as a crew; guest appearances enrich the world without replacing them.
5. Exploration and secrets pay off concretely in the final level.
6. The 9 Bit reveal is emotionally meaningful, funny in places, dangerous in combat, and not a generic “evil twin” story.

## Creative pillars

### Seven corrupted cartridges

The simulation uses archived 16-bit game grammar as containment shells. This makes the genre changes a plot device, not a collection of unrelated prototypes.

### Music is systemic

Each level's independent song profile may use beat/meter data, tempo maps, authored markers, sections, or adaptive layers to shape telegraphs, boosts, entrances, puzzle pressure, and boss phases. The musical relationship changes with the genre; off-beat or no-grid normal play remains valid.

### Dead-media BARCODE

Public-access control rooms, VHS wounds, CRT shrines, street-level hip hop, obsolete hardware, badly managed broadcasts, corporate compliance systems, and 16-bit grime define the look and humor.

### Community lives in the walls

Community echoes appear in signs, stations, guides, hidden channels, vendors, score tables, routes, support modules, and secrets. They do not become disposable enemy fodder.

### Finale payoff

Every guaranteed Stem Key opens the endgame. Every optional Signature Module changes Level 7. The player explores and prepares before finding 9 Bit.

## Scope guard

Make seven polished, replayable, compact levels—not seven full commercial games. Recommended first-clear targets are 12–18 minutes for Levels 1–4 and 6, 20–30 minutes for Level 5, and 30–45 minutes for Level 7.
