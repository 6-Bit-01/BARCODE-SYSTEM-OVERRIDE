# Campaign Master Design

## Story spine

The simulation says six missing Stem Keys must be recovered from six damaged sectors. Each sector has rebuilt itself using a different archived game grammar and plays its own distinct song. A recovered key unlocks the corresponding layer in a separately produced intermission/Level 7 Full Mix arrangement and exposes more evidence that the sectors are containment shells around Partition 09.

Reveal cadence:

1. Level 1 detects an unnamed phase-inverted waveform.
2. Level 2 receives a pursuer transmission in a distorted version of 6 Bit's cadence.
3. Level 3 finds “Partition 09: rejected response profile.”
4. Level 4 reconstructs the separation record but loses the initiator field.
5. Level 5 lets 9 Bit speak: the system kept the version it considered easier to broadcast.
6. Level 6 shows 9 Bit fully and reveals his location beneath Tower Apex.
7. Level 7 restores the context, lets the player prepare, finds 9 Bit, fights him, and resolves what happens next.

## Campaign map

| L | Title | Genre | Lead | Stem Key | Optional module | Boss |
|---|---|---|---|---|---|---|
| 1 | Dead Air District | platformer/brawler | 6 Bit | Voice | Beat Anchor | Program Director / owner-approved fit |
| 2 | The Cache Line | pseudo-3D racer | Cache Back | Bass | Phase Capacitor | Tollkeeper |
| 3 | Broadcast Slum | run-and-gun | 6 Bit | Drums | Breach Emitter | EULA-88 |
| 4 | Buffer Underflow | linked-pair grid puzzle | DJ Floppydisc | Synth | Restore Point | Memory Leak |
| 5 | Signal Preserve | compact party RPG | original four | Samples | Crew Link | Curator |
| 6 | Firewall Cathedral | raycast FPS | Mac Modem + assists | Noise/FX | Root Credential | Root Daemon |
| 7 | Negative Space | first-person party RPG | original four | Full Mix | consumes all prior flags | 9 Bit |

## The Full Mix

Every completed level grants one guaranteed Stem Key. Stem Keys cannot be missed, lost, consumed, or tied to difficulty/timing grade. The six combine into the Full Mix, the only campaign gate for Level 7. They are stable progression/reward identities, not permission to layer the six unrelated level songs. Their audible payoff uses a separate compatible six-layer arrangement or an approved premix with bounded alternates.

Optional Signature Modules are found through authored side routes. They open context, shortcuts, equipment, abilities, recovery, and boss advantages in Level 7. A missing optional module never makes the game unwinnable and never blocks the main ending route.

## Lost Data

Keep 28 one-time pieces with the locked `3 / 4 / 5 / 4 / 5 / 4 / 3` distribution. Replace random timer spawns with fixed authored locations or rewards. Each ID is deterministic and persisted. Lore affects understanding/endings, not base combat strength.

## Character continuity

Historic sector continuity remains the default: Cache Back owns Level 2, DJ Floppydisc owns Level 4, and Mac Modem owns Level 6. Level 5 establishes the full four-person party; Level 7 pays it off. Cameos never receive selection slots or party portraits.

## Intermissions

After each level:

1. results and collectible summary;
2. recovered Stem Key activates its layer in the separate intermission mix;
3. one short story transmission;
4. channel-select cartridge activates;
5. save commits after the result, before the next level.

## Endings

Retain the older ending labels as working candidates tied to knowledge and resolution, not arbitrary score:

- **Static Burial:** destroy/quarantine outcome with incomplete context;
- **Ejected Echo:** 9 Bit remains separate/contained and the apparatus is destroyed;
- **The Broadcast Returns:** full-context reintegration or another owner-approved restorative outcome.

Exact canon, unlock thresholds, and whether all are player choices remain open. The boss fight occurs in every route.
