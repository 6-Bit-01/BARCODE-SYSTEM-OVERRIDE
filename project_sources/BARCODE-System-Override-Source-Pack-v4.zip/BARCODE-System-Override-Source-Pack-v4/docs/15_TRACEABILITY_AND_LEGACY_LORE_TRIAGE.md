# Traceability and Legacy Lore Triage

## Conversation/source coverage

This overhaul used every project-specific decision available in the current request, the recovered BARCODE conversation context available to ChatGPT, Source Pack v2, the live repository, and PR history. Raw private conversation transcripts are not reproduced in this archive; recovered conversation state is summarized into explicit decisions below. If the owner supplies an older transcript that was not present in the recovered context, newer direct owner instruction still wins.

Source codes:

- **NOW:** owner's 2026-07-15 overhaul request;
- **CTX:** recovered prior BARCODE conversation decisions/lore;
- **V2:** attached Source Pack v2;
- **REPO:** audited live source/assets/tests;
- **SYN:** working design synthesized for v3 and retained or refined by v4;
- **OPEN:** deliberately unresolved owner decision.

## Decision trace

| ID | Sources | Trace |
|---|---|---|
| D-001 | NOW, CTX | Current request defines six remaining levels plus the existing Level 1. |
| D-002 | CTX, V2 | Recovered roster lock: original four only. |
| D-003 | NOW, CTX, V2 | Community requested densely; recovered rule limits guests to cameos/support/power-ups. |
| D-004 | CTX, V2 | Simulation premise retained from prior planning. |
| D-005 | NOW, CTX, V2 | Current finale request plus recovered origin: 9 Bit comes from rejected/negative parts of 6 Bit. |
| D-006 | CTX, V2, REPO | Intro art/dialogue lock and no 9 Bit insertion; runtime mapping audited. |
| D-007 | CTX, V2 | *Observer Not Found* kept separate. |
| D-008 | CTX, V2 | City Scrambler discarded. |
| D-009 | NOW, CTX, REPO, SYN | Improve current Level 1 with existing art; platformer/brawler vertical slice is the coherent rehaul. |
| D-010 | NOW | Required homage genres taken directly from the current request. |
| D-011 | NOW | First-person RPG/combat/exploration finale, prior-item advantages, preparation, 9 Bit. |
| D-012 | CTX, V2, REPO | Jammer ally/environment rule overrides current destroyable-enemy implementation drift. |
| D-013 | CTX, V2 | 6 Bit Level 1 movement lock. |
| D-014 | CTX, V2 | Off-beat actions always work; rhythm grants bonuses. |
| D-015 | CTX, V2 | W3T TDDY ally/Tower reveal; clarified as guaranteed support, not a seventh gate. |
| D-016 | CTX, V2 | Fixed 28-piece distribution. |
| D-017 | CTX, SYN | Historic sector/character continuity determines the recommended order; owner approval pending. |
| D-018 | NOW, SYN | Owner allowed Tetris or Dr. Mario; linked-pair patching is the asset-efficient recommendation. |
| D-019 | NOW, SYN | Prior-level items must matter in Level 7; Full Mix/Modules make required and optional effects explicit. |
| D-020 | SYN | Reveal cadence recommendation; exact narrative copy remains owner-controlled. |
| D-021 | OPEN | 9 Bit resolution/ending canon not supplied. |
| D-022 | REPO, SYN, OPEN | Existing boss art exists; identity/fit is not approved. |
| D-023 | SYN, OPEN | Working titles/order are useful for production but not asserted as final shipping names. |
| D-024 | REPO, OPEN | Level 1 audio timing was measured; later music does not yet exist in the audited sources. |
| D-025 | REPO, OPEN | Fixed desktop canvas exists; final platform/accessibility targets were not supplied. |
| D-026 | NOW, V2 | Broad overhaul directly supersedes v2 cleanup-only scope. |
| D-027 | NOW, V2 | Current request fixes seven total and the required genre set. |
| D-028 | NOW, CTX, REPO | Current quota/destroy-Jammer implementation conflicts with authored-level and non-enemy locks. |
| D-029 | CTX, V2, REPO | Random lore delivery conflicts with the fixed deterministic collection plan. |
| D-030 | NOW, REPO | `maxLevel: 5` and old victory claims are implementation drift. |

## Legacy lore quarantine

The audit found two active raw pools:

- `src/game/lost-data.js`: 95 strings, randomly selected for only three Level 1 pickups;
- `src/engine/lore.js`: 46 strings, displayed through a separate random-lore surface.

All **141 strings are quarantined as final prose**. None automatically migrates into the 28-piece plan. This avoids canon-by-random-line and duplicate story authorities.

| Legacy category | Examples of the problem | current treatment |
|---|---|---|
| origin/creator assertions | who built BARCODE/6 Bit, human vs non-human origin, debugging-tool claims | reject unless separately owner-approved |
| premature 9 Bit claims | exact motives, abilities, fear of fragments, appearances before approved cadence | reject; use the controlled seven-level reveal plan |
| spiritual/identity assertions | soul pieces, true name, “person before,” programming origin | quarantine; may conflict with performer identity and simulation ambiguity |
| fourth-wall/stat triggers | “the player is winning/strong enough,” randomized virtue triggers | reject as delivery logic and final copy |
| repetitive poetic variants | dozens of hope/courage/resilience/color/future formulations | do not migrate; write one purposeful piece per stable ID |
| dead-media/world texture | 60 Hz/59.94, VCR/Walkman, blank tapes, ghost lanes, obsolete terminals | thematic hooks only; rewrite and approve in the relevant level |
| supporting/community claims | Cliff, Miss Bit, crew inventions/history, unverified cameos | require canon/cameo approval before reuse |

`data/lore-plan.json` therefore stores IDs, mandatory-vs-optional placement, reveal purpose, and approval state—not unapproved finished dialogue. The physical lore object can be reused, but random spawn timing and random text selection are superseded.

## What to do with the old arrays

Keep them loaded only until PR #9/PR #11 replaces delivery and proves no references remain. Then move raw legacy copy to a non-`.js` archive or remove it in a dedicated, reversible cleanup commit. Do not leave an active second lore authority behind the new data file.
