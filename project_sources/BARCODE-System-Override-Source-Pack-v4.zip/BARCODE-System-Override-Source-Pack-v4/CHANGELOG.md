# Changelog

## v4.0 — 2026-07-15

- Recorded the owner's rejection of PR #4 and removed every merge, smoke-test, and branch dependency on it.
- Locked one distinct gameplay song and independent music profile per level; no global BPM, meter, phrase length, loop, cue map, or required beat grid.
- Added the level music-profile/session contract with marker-only, fixed-tempo, and tempo-map support.
- Separated the six Stem Key progression IDs and Level 7 Full Mix arrangement from the seven unrelated gameplay songs.
- Replaced the next Codex task with a fresh main-based fixed profile/transport PR; it proves different fixed tempos/meters/grid origins and no-grid behavior while deferring speculative tempo-map/cue/seek work.
- Renumbered the lifecycle, enemy, combat, authored-stage, campaign-kernel, Level 1 completion, and asset-foundation sequence around the rejected PR.
- Updated level briefs so music can shape each genre differently without forcing beat input into every mechanic.

## v3.0 — 2026-07-15

- Re-audited live GitHub `main` at `29366454…` and open PR #4 at `5fc8ceb…`.
- Reclassified v2 as cleanup-era governance rather than current source truth.
- Locked the seven-level campaign and the five required homage genres.
- Added the first-person Level 7 exploration/preparation/9 Bit finale.
- Reconciled current direction with historic sector and character continuity.
- Designed the Full Mix, six Stem Keys, six Signature Modules, stable item IDs, and non-blocking finale dependencies.
- Rebuilt Level 1 as an authored vertical slice using current art plus additive props and collision overlays.
- Added current asset registry, Makko evidence/capabilities, production gaps, and optimization plan.
- Added campaign kernel, Level Adapter, save schema, performance budgets, and QA plan.
- Added a dense data-driven community Easter-egg registry and permission tiers.
- Replaced obsolete PR prompts with PR #4 closeout and the next five implementation PRs.
