# Next Codex PR Prompt — PR #5 Level-Aware Music Profiles and Fixed Transport

Attach or unpack this v4 source pack into the Codex workspace, provide its path, and copy this entire file into a new Codex task after PR #4 is closed or while it remains safely unmerged.

---

Work in `6-Bit-01/BARCODE-SYSTEM-OVERRIDE` from the latest `main`. First confirm the provided `BARCODE-System-Override-Source-Pack-v4` path is readable; if it is missing, stop and ask for it rather than guessing decisions. Inspect the repository, current `main`, open-PR metadata, tests, active script order, and pack before editing.

PR #4, `feat: establish authoritative music clock`, is owner-rejected. Inspect its status/metadata only. Do not fetch or read its diff, patch, branch files, or commits; do not merge, cherry-pick, copy, or stack on it. If it remains open, leave it untouched and continue from `main`. If any PR #4 commit reached `main`, stop with a read-only divergence report because the approved base changed.

Create a narrow branch and open **PR #5: level-aware music profiles and fixed transport**. Build it fresh from current `main` and this pack.

## Owner correction controlling this PR

Every level uses a different gameplay song. Tempo, meter, grid origin, sections, loop/end policy, sources/stems, cues, and judgment rules belong to that song's profile. Nothing inherits Level 1's 146 BPM, 4/4, four-bar phrase, three stems, or 211-second restart. A song may later use a tempo map, authored markers, or no beat grid. Do not turn seven genres into one rhythm game.

## Narrow required outcome

Add the profile/transport seam needed to remove Level 1 timing constants from scattered active code and prove that a future level can select different fixed timing—or no grid—without inheriting Level 1. Migrate current Level 1 through an explicit `legacy-compatibility` profile. Do not implement variable-tempo interpretation, meter changes, gameplay cue delivery, seek, adaptive mixing, another level, or a lifecycle rewrite in this PR.

## Current-main facts to verify

- `src/engine/audio.js` hardcodes three Level 1 stems, `60 / 146` timing, numeric fallback BPMs, and a recursive timer-based scheduler. Its 211-second manual fade/restart exists alongside looping sources with unequal decoded lengths.
- `src/game/rhythm.js` separately hardcodes 146 BPM, 4-beat bars, 4-bar/16-beat phrases, and profileless 32-BPM fallback paths in a different time domain.
- `src/engine/cutscene.js` calls `startBackgroundRhythm(146)` from multiple completion/fallback paths after music startup.
- the loaded fallback in `src/game/debug-commands.js` derives another BPM numerically.
- no gameplay-song/profile registry exists.

Report changed facts before implementation and adapt only within this PR's purpose.

## Scope

1. Add browser-global, namespaced modules under `window.BARCODE` for an immutable music-profile registry and active fixed transport/session. Add correct `window.FILE_MANIFEST` entries. Load them in `index.html` before `src/engine/audio.js`; update the script/global map and regenerate the repository baseline inventory.
2. Profile selection uses an exact ID. Missing/invalid IDs produce a no-profile/degraded session; never fall back to Level 1, the prior profile, 146, 4/4, or any numeric default.
3. Validate a multi-source arrangement with stable source/asset IDs, the existing URL or resolver, required/optional status, gain, offset, native-loop flag, fallback role, playback policy, optional fixed grid, and named judgment rules. Freeze or defensively copy registered data.
4. Register **only `level-01.main`** at runtime. Move the existing three source IDs/URLs, gains, native-loop flags, 146 BPM, 4/4, 32-beat establishment, 16-beat/four-bar phrase presentation, implemented 60/100 ms judgment windows, and 211-second manual restart policy into an explicit Level-1 compatibility block. Mark it `legacy-compatibility`, not verified and not reusable as a default.
5. Model 211 as `legacyManualRestartSec` or equivalent Level-1-only compatibility policy. Do not reinterpret it as a verified musical loop end, set new `AudioBufferSourceNode.loopStart/loopEnd`, truncate/stretch sources, remove the existing fade/wait, or change unequal stem assets.
6. Define playback time separately from musical grid phase. Anchor playback position to the exact scheduled `AudioContext.currentTime` source start. Preserve the current Level 1 first-boundary phase and 32-beat establishment counters through a profile grid-origin/compatibility offset if inspection confirms they begin later than source start. Do not silently shift judgment phase. If exact behavioral equivalence is impossible, document the measured phase delta and require owner A/B approval.
7. The transport supports two runtime modes in this PR: playback/no-grid and one fixed tempo/meter grid. Reserved marker fields may be validated as inert data but are not delivered. A no-grid profile returns intentional judgment-unavailable state and never shows timing data.
8. Provide immutable sampling, fixed-grid position, nearest-grid judgment, boundary output/subscription, generation invalidation, and bounded hitch/resync behavior from Web Audio time. The existing frame owner pumps polling. Duplicate idempotent starts do not advance generation; only effective state/source transitions do. Unequal native source wraps are not transport loop generations; the coordinated manual restart is. Do not use recursive `setTimeout`/`setInterval`, another RAF, or `Date.now` as musical authority.
9. Preserve the implemented nearest-beat formula: perfect at or within 60 ms, excellent at or within 100 ms, otherwise miss. Do not revive or apply the dead `-20 ms` compensation. Keep future input calibration distinct from grid/downbeat offset.
10. Update `src/engine/audio.js`, `src/game/rhythm.js`, every relevant `src/engine/cutscene.js` completion/fallback path, and the loaded `src/game/debug-commands.js` fallback to read the selected profile/transport. Remove numeric default BPM arguments and derived fallback BPMs from active timing APIs.
11. Touch `src/game/game-initializer.js` only enough to select `level-01.main` before `audioSystem.init()`/`loadMusicTracks()`. Do not unify first Start/retry/restart here; that remains PR #6.
12. Keep current Level 1 source URLs, gains, load/fallback behavior, fade/restart behavior, intro presentation, controls, rhythm-mode gating, cooldown, miss/damage results, and visual presentation unchanged except for a separately reported/owner-approved phase correction.
13. Document the API, time domains, Level 1 compatibility values, unequal stem debt, and future profile rule. Do not invent runtime profiles, assets, BPMs, cue maps, or judgment mechanics for Levels 2–7. Reserved future tempo-map/cue fields may be schema-validated as inert data but are not interpreted.

## Deterministic proof

Add focused tests for:

- exact playback anchor and track-time position;
- Level 1 legacy first-boundary phase and 32-beat establishment/counter compatibility;
- synthetic fixed profiles with deliberately different BPM, meter, grid origin, phrase presentation, and restart/loop configuration;
- no-grid judgment-unavailable behavior;
- unknown-profile selection proving no Level 1 or previous profile source/grid/judgment survives;
- active Level 1 selection before audio loading;
- unchanged Level 1 source IDs/URLs/gains/fallback policy and manual 211-second fade/restart semantics;
- implemented 60/100 ms thresholds with no `-20 ms` compensation;
- repeated idempotent start/background-start calls retaining one active generation; effective stop/restart/profile changes advance it;
- native Level 1 buffer wraps do not count as session loops/generations, while the coordinated 211-second restart does;
- stop/restart/reconfigure invalidation, profile switching, and bounded hitch recovery;
- transport-owned listener/source/resource counts stable across isolated repeated cycles;
- active music/rhythm/configuration paths consuming the profile rather than hardcoding `146`, `211`, `32`, four-beat bars, or four-bar phrases;
- no recursive timing scheduler or second RAF in the transport.

Run `npm test`, all repository JavaScript syntax audits/checks, new targeted tests, required baseline regeneration/check, and `git diff --check`. Use repository-local synthetic fixtures only; no Makko credentials or new network assets.

## Hard boundaries

- no PR #4 patch/branch/code inspection or ancestry;
- no tempo-map interpretation, meter changes, live cue delivery, seek, adaptive arrangement authoring, or future-level implementation;
- no new song/audio asset, stem re-export, URL, gain rebalance, or final metadata guess;
- no app-wide lifecycle unification; automated leak guarantees cover transport-owned resources only;
- no enemy/Jammer rewrite, combat/control change, stage, boss, progression, save, campaign router, full Level Adapter, new art, or broad performance work;
- no intro image/dialogue edits and no 9 Bit insertion;
- no bundler/module conversion; preserve Makko's browser-global load model;
- no merge. Open a focused PR and report base/head SHA, commits, changed files, tests, remaining Makko checks, known debt, and rollback steps.

## Owner Makko/browser smoke checklist to include

These whole-app checks are owner evidence, not permission to absorb PR #6 lifecycle work.

1. Duplicate the project and load from a clean browser session.
2. Start normally; finish and separately skip the locked intro. Both paths start one copy of the existing Level 1 music.
3. A/B against current `main`: music content/gains/fade-restart behavior, first rhythm boundary, 32-beat establishment, rhythm UI, and attack judgment phase.
4. Verify existing movement, rhythm-mode gating, early/on-time/late miss behavior, cooldown, and damage results are unchanged. This PR does not make attacks always available.
5. Trigger repeated background-start calls, pause/resume, death, and restart. Report existing lifecycle defects separately; the merge gate is no new duplicate transport generation/events/sources or unbounded resync behavior.
6. Cross the existing 211-second manual restart. Confirm no new gap, overlap, fade change, duplicate event, source truncation, or console error.
7. Force degraded/missing audio if Makko permits; confirm no Level 1 timing profile leaks into a deliberately unknown/no-profile test path.
8. Record PASS, PASS WITH NOTES, or FAIL with browser/device, A/B observations, and exact reproduction.

---
