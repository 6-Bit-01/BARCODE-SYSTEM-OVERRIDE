# Next Five PR Cards

Run one at a time. Merge and owner-smoke the prior PR before starting the next. Every PR begins from current `main`, preserves Makko/browser-global compatibility, adds focused tests, and ends as an unmerged PR with a plain owner checklist. PR #4 is rejected history and never a dependency.

## PR #5 — Level-aware music profiles and transport

Use `NEXT_CODEX_PR.md`. Replace scattered Level 1 timing configuration with a profile-configured fixed transport built fresh from `main`. Preserve explicit legacy behavior, prove deliberately different synthetic fixed tempos/meters/grid origins/playback policies plus no-grid judgment-unavailable behavior, and create no Levels 2–7 content. Variable tempo/meter interpretation, live cue delivery, and seek are deferred.

## PR #6 — Lifecycle unification

Route first Start, retry, and restart through one initializer. Add one runtime state owner for `idle / starting / running / paused / stopping / failed`; suspend/resume the game loop, active music transport, mixer, and current systems; dispose owned resources; keep presentation/gameplay unchanged. Test repeated start/pause/restart/stop and failure recovery without multiplied resources.

## PR #7 — Single enemy owner; Jammer becomes environment

Consolidate active behavior from `enemies.js`, `jammer-fix-patch.js`, spawn patch, and collision patch behind one enemy manager. Delete double integration and duplicate damage/progression side effects; normalize all timers to one unit; prevent exact-overlap NaN; continue collision checks after a Jammer pair; dispose crowd/Jammer audio/timers. The Jammer may trigger audiovisual/environmental changes but is never targeted, damaged, counted, or destroyed. Preserve current art and approximate encounter feel. Add tests for one update/entity/frame, collision-pair continuation, zero-distance resolution, timer expiry, kill accounting once, and cleanup.

## PR #8 — 6 Bit combat contract and semantic actions

Add an action layer for keyboard/gamepad and route Level 1 through it. Base movement is left/right plus one jump. `primary` always attacks; the Level 1 profile's verified or explicit `legacy-compatibility` judgment can add bounded damage, stagger, combo, or recovery bonuses. Remove duplicate damage paths, raw beat-gated attack permission, advertised no-op dash, production debug keys, and fast-fall/stomp drift. Do not add double jump, wall slide, slide, Beat Dash, or another required movement ability. Keep existing animation references; use a temporary readable overlay if attack art is not yet approved. Test action without timing judgment, timing bonus, single damage application, remap/gamepad parity, and pause suppression.

## PR #9 — Authored Level 1 stage and presentation

Replace the flat endless quota sandbox with data for Boot Alley, H3LLCAT Block, Dead Channel Plaza, Flyby Row, and Relay Stage. Use current BG/FG/title/traffic art; render BG and FG aspect-correctly; add code-native placeholder props and explicit collision overlays for authored routes; add arena/milestone gates and checkpoints; schedule traffic through stable Level 1 profile cues with readable fallback timing; bound all spawns. Remove “kill 20 then destroy Jammer.” Jammer triggers the Relay Stage transition, never combat. Include three fixed lore slots but do not author final prose. Test checkpoint/restart, milestone gating, no invisible required platforms, deterministic spawns, degraded-audio fallback, and cleanup.

## Immediately after these five — PR #10 campaign kernel and save

Implement the minimal `GameApp`, `LevelDirector`, `CampaignStore`, `DisposableScope`, and Level Adapter registration. Promote PR #8's `ActionInput` and PR #5's profile-driven music service rather than recreating either. Wrap Level 1; add a code-native development cartridge rather than Level 2 art. Prove versioned save/backup/recovery, channel/results flow, adapter teardown, and a development Level 7 door whose state reads `module.beat_anchor` by stable ID. Do not build all genre engines or the Level 1 boss here.

## Then — PR #11 Level 1 completion

After PR #10 is merged and the owner approves boss identity/art fit, implement the Level 1 boss, natural transition, three fixed lore pieces, Voice Stem Key, optional Beat Anchor, result/save handoff, and complete vertical-slice test route. The boss is music-readable but always damageable. Completion without Beat Anchor, lore, or strong timing grade must work.

## Completion report required for every PR

- base/head/commit and link;
- why each changed file is in scope;
- automated commands and actual results;
- manual browser/Makko checks performed and still required;
- screenshots or short captures for visible changes;
- known risks and rollback path;
- owner verdict block: PASS / PASS WITH NOTES / FAIL.
