# BARCODE: SYSTEM OVERRIDE — Active Source Pack v4

**Version:** 4.0  
**Date:** 2026-07-15 (America/Los_Angeles)  
**Repository:** `6-Bit-01/BARCODE-SYSTEM-OVERRIDE`  
**Audited main:** `29366454d6cebbd8aca65321e5b191fd88e43e88`  
**Rejected branch:** PR #4, head `5fc8ceb3d38be3fa1f9d2447a8ab15982394af94`; close without merge

This is the controlling design, production, asset, lore, and engineering source pack for the seven-level top-down overhaul of **BARCODE: SYSTEM OVERRIDE**. It replaces Source Pack v3 as the current planning authority; v3 had already superseded the cleanup-era v2 pack.

## Start here

1. Read `PROJECT_INSTRUCTIONS.md` and `DECISION_REGISTER.md`.
2. Use `FILE_INDEX.md` to navigate the full packet.
3. Read `CURRENT_STATE.md` before making claims about what already works.
4. Use `docs/03_CAMPAIGN_MASTER_DESIGN.md` for the full campaign.
5. Use the matching file under `levels/` before changing a level.
6. Use `docs/06_CURRENT_REPOSITORY_AUDIT.md` and `docs/07_RUNTIME_ARCHITECTURE.md` before editing code.
7. Use `assets/ASSET_REGISTRY.json` and `assets/ASSET_NEEDS_BY_LEVEL.csv` before requesting or wiring art.
8. Use `prompts/NEXT_CODEX_PR.md` for the next implementation step from current `main`. Never merge, copy, or stack on PR #4.

## Campaign in one sentence

A corrupted recovery simulation rebuilds itself as seven different 16-bit-era game cartridges; the original BARCODE crew recover six Stem Keys that unlock a separately authored Full Mix, discover that 9 Bit was created from the rejected parts of 6 Bit, and carry everything they found into a first-person RPG finale where preparation changes the route and battle.

## Recommended seven-level production map

| Level | Display title | Historic sector continuity | Mechanical reference | Spotlight |
|---|---|---|---|---|
| 1 | Dead Air District | Cyberpunk City | Earthworm Jim-era platform action + brawler | 6 Bit |
| 2 | The Cache Line | Cache Back's Subway | Rad Racer | Cache Back |
| 3 | Broadcast Slum | Broadcast Slum | Contra | 6 Bit, with crew support |
| 4 | Buffer Underflow | Rhythm Field | Dr. Mario branch of Tetris/Dr. Mario | DJ Floppydisc |
| 5 | Signal Preserve | Industrial Underline | Pokemon-style compact party RPG | All four |
| 6 | Firewall Cathedral | Structure Core | DOOM | Mac Modem lead; crew assists |
| 7 | Negative Space | Tower Apex | First-person party RPG/combat/exploration | All four; 9 Bit finale |

The game names are internal mechanical references. Shipping art, names, characters, music, maps, UI trade dress, and assets remain original to BARCODE. Every level has its own gameplay song and level-owned timing profile; no campaign-wide BPM, meter, phrase length, or loop is assumed.

The seven-level count, five requested homage genres, Level 7 format, and character/canon boundaries are locked. The exact order, working display titles, and Dr. Mario linked-pair branch are the recommended plan pending the owner's explicit approval; see `DECISION_REGISTER.md`.

## What this pack contains

- a current repository and Level 1 audit;
- locked canon and supersession records;
- complete campaign, item, save, finale, and ending architecture;
- seven level briefs;
- a verified current-asset audit inventory, explicit production gaps, and per-level production matrix;
- a data-driven community Easter-egg plan;
- Makko/Codex/OpenArt workflow and export rules;
- the implementation roadmap, QA matrix, owner packet, and next Codex PR prompt.

This pack does **not** claim that browser/Makko gameplay was run by ChatGPT. The owner remains the runtime authority for Makko import, presentation, game feel, audio, camera, sprites, and restart behavior.

This archive is the planning/source-of-truth companion to the live GitHub repository; it is not a bundled replacement copy of the repository's source tree. Re-audit the referenced commit before code work if `main` has moved.
