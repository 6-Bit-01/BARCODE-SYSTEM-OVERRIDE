# Decision Register

Status values: **LOCKED**, **WORKING**, **OPEN**, **SUPERSEDED**.

| ID | Status | Decision |
|---|---|---|
| D-001 | LOCKED | Seven major levels total. |
| D-002 | LOCKED | Only 6 Bit, DJ Floppydisc, Cache Back, and Mac Modem are playable. |
| D-003 | LOCKED | Cameos/community/collaborators are visual, story, transmission, merchant, route, assist, or power-up presences only. |
| D-004 | LOCKED | The game takes place inside a simulation. |
| D-005 | LOCKED | 9 Bit is the byproduct of negative/rejected parts separated from 6 Bit. |
| D-006 | LOCKED | Existing intro art and dialogue are not redone; 9 Bit is not inserted into it. |
| D-007 | LOCKED | *Observer Not Found* remains separate. |
| D-008 | LOCKED | City Scrambler is discarded legacy. |
| D-009 | LOCKED | Level 1 is a cyberpunk/dead-media 16-bit platformer/brawler with music-aware combat and current assets. |
| D-010 | LOCKED | Levels 2–6 use Rad Racer, Contra, Dr. Mario/Tetris, Pokemon, and DOOM mechanical grammar—one each. |
| D-011 | LOCKED | Level 7 is first-person RPG/combat/exploration, uses items from Levels 1–6, lets the player prepare, and ends with 9 Bit. |
| D-012 | LOCKED | The jammer is a trigger/environmental system, not an enemy or kill gate. |
| D-013 | LOCKED | 6 Bit Level 1 movement stays left/right + one jump; no new required movement power. |
| D-014 | LOCKED | Basic actions always work. Where a level explicitly enables musical judgment, timing grants bonuses rather than permission to act. |
| D-015 | LOCKED | W3T TDDY is an ally and provides guaranteed route revelation/Tower-access support; never an enemy and never an extra missable gate beyond the six Stem Keys. |
| D-016 | LOCKED | Lore plan remains 28 one-time pieces distributed `3 / 4 / 5 / 4 / 5 / 4 / 3`. |
| D-017 | WORKING | Level order follows historic sector continuity: Cache Back Level 2, DJ Floppydisc Level 4, Mac Modem Level 6. |
| D-018 | WORKING | Dr. Mario-style linked-pair matching is the Level 4 branch because it fits music/patching and is asset-efficient. |
| D-019 | WORKING | Six guaranteed Stem Keys open Level 7; six optional Signature Modules provide routes, powers, context, and boss advantages. |
| D-020 | WORKING | 9 Bit first speaks directly in Level 5 and appears fully in Level 6. |
| D-021 | OPEN | Final resolution: reintegration, contained separate existence, quarantine, or another owner-approved ending structure. |
| D-022 | OPEN | Final Level 1 boss identity and whether existing sector-boss art fits it. |
| D-023 | OPEN | Final shipping level titles. The current mechanical order and sector continuity are the recommended working map until owner approval. |
| D-024 | OPEN | Exact level tracks; verified tempo/marker/meter/offset/section/loop/cue profiles; level-local stem exports; and separate Level 7 Full Mix exports. |
| D-025 | OPEN | Final platform targets, controller glyph set, touch support scope, and minimum device performance target. |
| D-031 | LOCKED | Every level uses a different gameplay song with its own independent profile. Production timing metadata must be verified; tempo, tempo changes, meter, grid origin, sections, playback policy, sources/stems, and cues are never inherited from another level or a global default. |
| D-032 | LOCKED | A beat grid is optional per level. A level may use beat/bar judgment, authored time markers, section cues, or no input judgment at all; music influence does not make every level the same rhythm game. |
| D-026 | SUPERSEDED | “Cleanup only; not a broad redesign.” |
| D-027 | SUPERSEDED | “Exact number and order of levels remain open.” |
| D-028 | SUPERSEDED | “Defeat 20 enemies, then destroy the jammer.” |
| D-029 | SUPERSEDED | Randomly spawning lore fragments as the campaign collectible model. |
| D-030 | SUPERSEDED | `maxLevel: 5` and old victory/readme claims. |
| D-033 | SUPERSEDED | PR #4's rejected global 146 BPM music-clock implementation and any roadmap dependency on merging it. |
