# Project Instructions

## Authority order

When sources conflict, use this order:

1. the owner's newest direct instruction;
2. `DECISION_REGISTER.md` and `SOURCE_MANIFEST.json` in this pack;
3. other v4 files;
4. the current live repository and merged PR history for implementation truth;
5. Source Pack v3, Source Pack v2, and older conversations only where v4 explicitly retains them;
6. old code comments, deprecated files, archived prompts, and legacy README claims.

Never promote implementation drift into design authority. In particular, the kill quota, destroyable jammer, fast-fall/stomp, dormant boss hooks, `maxLevel: 5`, City Scrambler language, randomly selected lore, and old victory assumptions are not the future design.

## Non-negotiable content boundaries

- Only 6 Bit, DJ Floppydisc, Cache Back, and Mac Modem are playable.
- Cameos and collaborators are never player-controlled.
- Existing intro images and approved wording are locked.
- Do not insert 9 Bit into the intro.
- 9 Bit is formed from the negative parts separated from 6 Bit. He is not a generic evil clone.
- Never call 6 Bit, the player-avatar as a whole, or the BARCODE crew “the virus” in game-facing text. Mac Modem's established “good virus” metaphor is the named character exception.
- *Observer Not Found* is separate and supplies no automatic canon.
- City Scrambler is discarded legacy, not a boss or level.
- The jammer is a trigger/environmental event, not an enemy or kill gate.
- 6 Bit's Level 1 base movement is left/right and one jump. Do not add double jump, wall slide, Beat Dash, slide, or another required movement mechanic.
- Basic actions work without timing judgment. Where a level enables musical judgment, it adds advantage; it does not invalidate normal attacks, steering, shots, drops, or RPG moves.
- Every level has a different gameplay song. Never hard-code or globally inherit Level 1's BPM, meter, offset, phrase length, loop points, stems, or timing windows for another level.
- Do not force one musical interaction model across the campaign. Each level explicitly chooses beat judgment, cue/section choreography, markers-only behavior, or no timing judgment.
- Preserve approved Level 1 art. Add new props, collision overlays, telegraphs, and boss art only where necessary.
- Visual identity is underground hip hop, damaged public-access television, VHS, obsolete computing, dead-media broadcast, and 16-bit grime—not generic neon cyberpunk.

## Engineering operating rules

- Do not stack Levels 2–7 directly onto Level 1's globals.
- Introduce the campaign kernel and Level Adapter boundary before full new-genre implementation.
- Keep Makko compatibility. Makko parses every `.js` file even if `index.html` does not load it.
- No inactive syntax-failing `.js` file may remain in the repository.
- Avoid a big-bang bundler/module rewrite. A namespaced global architecture is acceptable while the runtime remains Makko-hosted.
- Every timer, listener, audio source, and animation loop created by a level must be disposable on `exit()`.
- Shared audio services may run one active level music session, but the active Level Adapter supplies the track profile. Unknown timing metadata remains unknown; code must not guess `146` or any other fallback BPM.
- Game code reads actions, not raw keyboard keys.
- Campaign progress is represented by stable IDs in a versioned save, never by live object references.
- All production assets need stable IDs, provenance, dimensions, anchors, hashes where available, approval state, and local/remote fallback information.
- Debug bypass keys and verbose per-frame logs are development-only and disabled in production.

## Required report for every implementation PR

Report:

- exact base and head SHAs;
- exact files changed;
- design decisions intentionally implemented;
- behavior deliberately preserved;
- static/unit/browser tests run;
- owner Makko test route;
- asset additions or URL changes;
- known debt left for a later PR;
- rollback instructions.
