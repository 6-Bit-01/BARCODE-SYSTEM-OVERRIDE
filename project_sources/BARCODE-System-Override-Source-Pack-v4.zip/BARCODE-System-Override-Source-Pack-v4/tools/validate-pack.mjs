import { createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];
const assert = (condition, message) => { if (!condition) errors.push(message); };
const readJson = (path) => JSON.parse(readFileSync(join(root, path), 'utf8'));

const required = [
  'README.md',
  'PROJECT_INSTRUCTIONS.md',
  'DECISION_REGISTER.md',
  'CURRENT_STATE.md',
  'SOURCE_MANIFEST.json',
  'data/campaign.json',
  'data/items.json',
  'data/lore-plan.json',
  'data/easter-eggs.json',
  'data/music-cue-plan.json',
  'assets/ASSET_REGISTRY.json',
  'assets/ASSET_NEEDS_BY_LEVEL.csv',
  'engineering/LEVEL_ADAPTER_CONTRACT.md',
  'engineering/MUSIC_PROFILE_CONTRACT.md',
  'engineering/SAVE_SCHEMA.md',
  'engineering/PERFORMANCE_BUDGETS.md',
  'engineering/LEVEL1_VERTICAL_SLICE_BLUEPRINT.md',
  'owner/OWNER_PACKET.md',
  'prompts/NEXT_CODEX_PR.md',
  'prompts/NEXT_FIVE_PRS.md',
  'references/AUDITED_SPRITES_MANIFEST.json',
  'references/AUDITED_AUDIO_MANIFEST.json',
  'references/BARCODE-System-Override-Source-Pack-v3-SUPERSEDED.zip',
  'references/BARCODE-System-Override-Source-Pack-v2-SUPERSEDED.zip',
  'visuals/LEVEL_1_ASSET_CONTACT_SHEET.png',
  'visuals/LOCKED_INTRO_CONTACT_SHEET.png'
];
for (const path of required) assert(existsSync(join(root, path)), `missing required path: ${path}`);

const walk = (dir) => readdirSync(dir).flatMap((name) => {
  const path = join(dir, name);
  return statSync(path).isDirectory() ? walk(path) : [path];
});
const files = walk(root);

for (const path of files.filter((file) => file.endsWith('.json'))) {
  try { JSON.parse(readFileSync(path, 'utf8')); }
  catch (error) { errors.push(`invalid JSON ${relative(root, path)}: ${error.message}`); }
}

for (const path of files.filter((file) => file.endsWith('.md'))) {
  const text = readFileSync(path, 'utf8');
  const fences = text.match(/^```/gm)?.length ?? 0;
  assert(fences % 2 === 0, `unbalanced Markdown fences: ${relative(root, path)}`);
}

const campaign = readJson('data/campaign.json');
const items = readJson('data/items.json');
const lore = readJson('data/lore-plan.json');
const eggs = readJson('data/easter-eggs.json');
const music = readJson('data/music-cue-plan.json');
const manifest = readJson('SOURCE_MANIFEST.json');
const itemIds = new Set(items.items.map(({ id }) => id));

assert(campaign.levels.length === 7, 'campaign must contain exactly seven levels');
assert(new Set(campaign.levels.map(({ id }) => id)).size === 7, 'level IDs must be unique');
assert(campaign.campaignGate.requiresAll.every((id) => itemIds.has(id)), 'final gate references unknown item');
for (const level of campaign.levels) {
  assert(existsSync(resolve(root, 'data', level.detail)), `${level.id} detail file does not exist: ${level.detail}`);
  if (level.guaranteedReward) assert(itemIds.has(level.guaranteedReward), `${level.id} has unknown guaranteed reward`);
  if (level.optionalReward) assert(itemIds.has(level.optionalReward), `${level.id} has unknown optional reward`);
}

const profileIds = new Set(music.profiles.map(({ profileId }) => profileId));
assert(music.profiles.length === 7 && profileIds.size === 7, 'music plan must contain seven unique level profiles');
assert(
  JSON.stringify([...profileIds].sort()) === JSON.stringify(campaign.levels.map(({ id }) => `${id}.main`).sort()),
  'music profile IDs must map exactly to level-01.main through level-07.main'
);
assert(music.principles.oneDistinctGameplaySongPerLevel === true, 'distinct per-level songs must remain locked');
assert(music.principles.globalDefaultBpm === null, 'global default BPM must remain null');
assert(music.principles.beatGridOptionalByLevel === true, 'beat grids must remain optional by level');
assert(
  JSON.stringify(music.profiles.filter(({ runtimeRegistration }) => runtimeRegistration).map(({ profileId }) => profileId)) === JSON.stringify(['level-01.main']),
  'only the Level 1 compatibility profile may be runtime-registrable before other tracks are approved'
);
assert(music.profiles.find(({ profileId }) => profileId === 'level-01.main')?.metadataStatus === 'legacy-compatibility', 'Level 1 must use the explicit legacy-compatibility metadata status');
assert(music.profiles.filter(({ profileId }) => profileId !== 'level-01.main').every(({ metadataStatus }) => metadataStatus === 'unverified'), 'future level profiles must remain unverified');
for (const level of campaign.levels) {
  assert(profileIds.has(level.musicProfileId), `${level.id} references unknown music profile: ${level.musicProfileId}`);
  const profile = music.profiles.find(({ profileId }) => profileId === level.musicProfileId);
  assert(profile?.levelId === level.id, `${level.id} music profile belongs to another level`);
}
assert(music.finaleArrangement.notBuiltFromLevelSongs === true, 'finale arrangement must remain separate from level songs');
assert(music.finaleArrangement.profileId === 'level-07.main', 'finale arrangement must use the Level 7 profile');
const stemKeyIds = items.items.filter(({ kind }) => kind === 'stem-key').map(({ id }) => id).sort();
assert(JSON.stringify(music.finaleArrangement.layerMap.map(({ stemKeyId }) => stemKeyId).sort()) === JSON.stringify(stemKeyIds), 'finale layer map must map every Stem Key exactly once');
assert(new Set(music.finaleArrangement.layerMap.map(({ audioAssetId }) => audioAssetId)).size === 6, 'finale audio layer IDs must be unique');
assert(music.finaleArrangement.layerMap.every(({ stemKeyId, audioAssetId }) => stemKeyId !== audioAssetId), 'Stem Key IDs must not double as audio asset IDs');
assert(manifest.rejectedPullRequest?.number === 4, 'manifest must record rejected PR #4');
assert(manifest.rejectedPullRequest?.ownerDisposition === 'close-without-merge-do-not-copy-or-stack', 'manifest must preserve PR #4 owner disposition');
assert(manifest.hardLocks.includes('distinct-song-and-music-profile-per-level'), 'manifest must lock distinct per-level music profiles');
assert(manifest.hardLocks.includes('no-global-bpm-meter-phrase-or-loop'), 'manifest must lock absence of global music timing defaults');

assert(items.items.length === itemIds.size, 'item IDs must be unique');
assert(items.items.filter(({ kind }) => kind === 'stem-key').length === 6, 'exactly six Stem Keys required');
assert(items.items.filter(({ kind }) => kind === 'signature-module').length === 6, 'exactly six Signature Modules required');
assert(items.items.filter(({ kind }) => kind === 'signature-module').every(({ optional }) => optional === true), 'all Signature Modules must be optional');

assert(lore.total === 28 && lore.entries.length === 28, 'lore plan must contain 28 entries');
const loreCounts = campaign.levels.map(({ id }) => lore.entries.filter(({ level }) => level === id).length);
assert(JSON.stringify(loreCounts) === JSON.stringify([3, 4, 5, 4, 5, 4, 3]), `lore distribution mismatch: ${JSON.stringify(loreCounts)}`);
assert(new Set(lore.entries.map(({ id }) => id)).size === 28, 'lore IDs must be unique');

for (const alias of eggs.aliases) {
  assert(Boolean(alias.id), `Easter egg alias lacks stable ID: ${alias.display}`);
  assert(Boolean(alias.approval), `Easter egg alias lacks approval state: ${alias.id}`);
  assert(Array.isArray(alias.levelHints) && alias.levelHints.length > 0, `Easter egg alias lacks level hints: ${alias.id}`);
  if (alias.tier === 'story' || alias.tier === 'functional' || alias.tier === 'story-functional') {
    assert(Boolean(alias.fallback), `story/functional Easter egg lacks fallback: ${alias.id}`);
  }
}
assert(eggs.recurring.some(({ id }) => id === 'w3t-tddy'), 'W3T TDDY recurring ID missing');
assert(!eggs.recurring.some(({ id }) => id === 'wet-tddy'), 'typo wet-tddy must not exist');

const csv = readFileSync(join(root, 'assets/ASSET_NEEDS_BY_LEVEL.csv'), 'utf8').trim().split(/\r?\n/);
const csvColumns = csv[0].split(',').length;
assert(csvColumns === 8, 'asset CSV must have eight columns');
for (let index = 1; index < csv.length; index += 1) {
  let quoted = false;
  let columns = 1;
  for (const char of csv[index]) {
    if (char === '"') quoted = !quoted;
    else if (char === ',' && !quoted) columns += 1;
  }
  assert(!quoted && columns === csvColumns, `asset CSV malformed at line ${index + 1}`);
}

const sha256 = (path) => createHash('sha256').update(readFileSync(join(root, path))).digest('hex');
assert(
  sha256('references/BARCODE-System-Override-Source-Pack-v3-SUPERSEDED.zip') === 'a465dd37be6b7a6b9766f94f0fadc7c34ca061624dd06a1151f2000804799078',
  'superseded v3 archive hash mismatch'
);
assert(
  sha256('references/BARCODE-System-Override-Source-Pack-v2-SUPERSEDED.zip') === '5fe76d38bd6d354926627ce72285efe7c307040d2d8cfe8424fb97605648d2b9',
  'superseded v2 archive hash mismatch'
);
assert(sha256('references/AUDITED_SPRITES_MANIFEST.json') === 'd1a267cb59399664a8b79330c3f902e5966a9143c9bed46c4bbf273ae3377f78', 'sprite manifest mirror hash mismatch');
assert(sha256('references/AUDITED_AUDIO_MANIFEST.json') === 'e686096fff117c489898642739d2f3ad76503b422cbf43dc605972293c7c7e45', 'audio manifest mirror hash mismatch');

for (const path of files.filter((file) => file.endsWith('.png'))) {
  const magic = readFileSync(path).subarray(0, 8).toString('hex');
  assert(magic === '89504e470d0a1a0a', `invalid PNG signature: ${relative(root, path)}`);
}

const hashManifestPath = join(root, 'FILE_HASHES.sha256');
if (existsSync(hashManifestPath)) {
  const hashLines = readFileSync(hashManifestPath, 'utf8').trim().split(/\r?\n/);
  const recorded = new Map();
  for (const line of hashLines) {
    const match = line.match(/^([0-9a-f]{64})  (.+)$/);
    assert(Boolean(match), `malformed FILE_HASHES line: ${line}`);
    if (!match) continue;
    recorded.set(match[2], match[1]);
    assert(existsSync(join(root, match[2])), `FILE_HASHES references missing file: ${match[2]}`);
    if (existsSync(join(root, match[2]))) assert(sha256(match[2]) === match[1], `checksum mismatch: ${match[2]}`);
  }
  const expected = files
    .map((file) => relative(root, file))
    .filter((path) => path !== 'FILE_HASHES.sha256');
  for (const path of expected) assert(recorded.has(path), `FILE_HASHES omits file: ${path}`);
}

if (errors.length) {
  console.error(`Source pack validation failed (${errors.length}):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log(`Source pack validation passed: ${files.length} files, 7 levels, 12 progression items, 28 lore IDs, ${eggs.aliases.length} community alias candidates.`);
