# Level 5 — Signal Preserve

**Historic sector:** Industrial Underline  
**Party:** 6 Bit, DJ Floppydisc, Cache Back, Mac Modem  
**Reference:** Pokemon  
**Mode:** compact top-down exploration + menu-driven turn battles  
**First-clear target:** 25–30 minutes  
**Lore:** 5 pieces

## Premise

The simulation preserves discarded loops, styles, rogue programs, and community influence beneath the industrial layer. One active crew member battles at a time; swapping is a turn.

## Scope

One compact settlement, two routes, one cave/venue space, one tower interior, friendly challengers, encounter zones, healing points, party menu, status effects, Samples, and Curator battle. Do not build a giant collectible RPG.

## Samples

The player does not capture people or cameos. Analyzing/defeating a rogue program records its rhythm as a **Sample**—equipment/consumable modifiers for the original four. Enemies include original Studio Rat anomalies, compression ghosts, bot accounts, genre mimics, and rogue signal animals.

## Party roles

- 6 Bit / Flow: balanced damage and timing flourish;
- DJ / Tempo: buffs, silence, speed, turn order;
- Cache / Archive: recovery, shield, restoration;
- Mac / Glitch: infection, high-risk damage/self-cost.

An optional song-specific confirm cue may add a modest flourish if later approved. The chosen move always resolves and the battle system does not require a beat grid.

## Boss — Curator

A classification intelligence that forces every signal into one marketable format. It changes genre filters/status rules between rounds, encouraging party swaps and Sample use.

## Rewards

- guaranteed: `stem.samples`;
- optional four-member route puzzle: `module.crew_link`;
- lore: `lore.l05.01`–`lore.l05.05`;
- hidden: `rat.l05`, `nulltv.l05`;
- story: 9 Bit first speaks directly and argues the system kept the marketable half.

The first direct 9 Bit transmission occurs on the mandatory route. Crew Link unlocks extra party response and context, not the first appearance or a required reveal.

## Candidate echoes

Mister N1CE Guide, Kaveman's Hollow, Dr3wB4by Blue recovery, Solo-So Echo station, Tonal Oracle, OREAGANOMIX shop, MZK-Queen Route, SKELLA Choir, Freeboot Signal. They remain guides, signs, shops, friendly challengers, and transmissions—not capturable enemies.
