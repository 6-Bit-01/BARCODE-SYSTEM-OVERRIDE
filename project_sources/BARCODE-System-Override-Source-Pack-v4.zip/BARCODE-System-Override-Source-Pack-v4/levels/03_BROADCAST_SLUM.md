# Level 3 — Broadcast Slum

**Historic sector:** Broadcast Slum  
**Lead:** 6 Bit; Mac Modem support/breach presence  
**Reference:** Contra  
**Mode:** side-on run-and-gun + one vertical ascent  
**First-clear target:** 15–18 minutes  
**Lore:** 5 pieces

## Premise

6 Bit assaults a licensing/security foundry that is stripping rogue broadcasts into approved product categories. Mac Modem breaches doors and weapon nodes without becoming a second controlled player.

## Core grammar

Run, single jump, crouch, directional aim, always-functional fire, weapon/transmitter pickups, destructible emplacements, bridge collapse, lift ascent, multi-part boss. Pickups use original BARCODE media-cartridge/transmitter shapes, not copied icons.

The Level 3 song can drive wave/setpiece cues and an optional reload/heat-vent bonus after its profile is approved. Normal fire and reload never wait for rhythm judgment.

## Acts

1. Foundry exterior assault.
2. Collapsing broadcast bridge.
3. Vertical freight lift, attacks from both sides.
4. Server hangar miniboss.
5. Terms-of-service core.

## Boss — EULA-88

A siege mainframe armored in endlessly scrolling approval clauses. Destroy physical checkbox nodes, survive original bullet patterns, and hit the exposed signature core.

## Rewards

- guaranteed: `stem.drums`;
- optional demolition route: `module.breach_emitter`;
- lore: `lore.l03.01`–`lore.l03.05`;
- hidden: `rat.l03`, `nulltv.l03`;
- story: first explicit “Partition 09: rejected response profile” log.

## Asset minimum

6 Bit shooting/crouch/hurt solution or modular weapon overlays, 4 enemy families, one miniboss, destructible foundry props, projectile/weapon FX, EULA-88 phases.

## Candidate echoes

MUTE-E-L8R locker, TIF.FY_B0MB demolition brand, Freeboot Signal, Kaveman's Hollow secret, SKELLA Choir broadcast sting, Dr3wB4by Blue recovery monitor.
