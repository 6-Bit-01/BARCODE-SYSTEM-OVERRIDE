# Level 6 — Firewall Cathedral

**Historic sector:** Structure Core  
**Lead:** Mac Modem  
**Support:** finite assists from 6 Bit, DJ Floppydisc, Cache Back  
**Reference:** DOOM  
**Mode:** fast raycast/pseudo-3D FPS maze  
**First-clear target:** 15–20 minutes  
**Lore:** 4 pieces

## Premise

Mac Modem descends under the polished Network interface into industrial public-access hell: coaxial intestines, CRT shrines, dead studios, tape vaults, cooling towers, and waveform stained glass.

## Core grammar

Hand-authored maze, fast navigation/strafe combat, frequency-key doors, wall switches, secrets, signal/ammo pickups, billboard enemies, weapon overlays, automap, and one large exit guardian.

Mac's normal weapon always fires. The Level 6 song may drive intensity, telegraphs, or an optional reload/alternate-fire bonus after its profile is approved. The other three appear as limited support calls, not selectable controlled characters in this level's first-clear design.

## Sections

1. intake studio and first key;
2. cooling maze and secret chain;
3. tape vault ambush;
4. dead-channel chapel;
5. root seal and boss.

## Boss — Root Daemon

The guardian process keeping the rejected partition sealed and everyone else out. Defeating it means the crew chooses to confront the truth, not automatically side with 9 Bit.

## Rewards

- guaranteed: `stem.noise_fx`;
- primary secret chain: `module.root_credential`;
- lore: `lore.l06.01`–`lore.l06.04`;
- hidden: `rat.l06`, `nulltv.l06`;
- story: 9 Bit appears fully and gives the final location challenge.

The full 9 Bit appearance and location challenge occur on the mandatory route. The Root Credential secret improves Level 7 access and defenses but does not contain either required story reveal.

## Asset minimum

Mac HUD/hands/weapons, 4–5 front-facing billboard enemy families, 3–4 weapon/ability overlays, wall/door/switch/floor/ceiling textures, keys/pickups, Root Daemon, three assist portraits/FX.

## Candidate echoes

NUL.TV/Willy the Warg dead channel, D34D1TE_ASH riddle terminals, M1ND_FANATIC architecture signature, Kaveman's Hollow secret, MUTE-E-L8R joke, BNL-01 status, Sheila control silhouette, Cliff vent accident.
