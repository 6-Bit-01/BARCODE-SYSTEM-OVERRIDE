# Level 7 — Negative Space

**Historic sector:** Tower Apex  
**Party:** original four  
**Mode:** first-person RPG/combat/exploration  
**First-clear target:** 35–45 minutes  
**Lore:** 3 pieces  
**Final boss:** 9 Bit

## Difference from Level 6

Reuse the raycast renderer/navigation foundation, but change the game: slower exploration, central hub, connected wings, party switching, inventory/equipment, dialogue/logs, map annotations, safe terminals, optional locked rooms, deliberate RPG combat, and preparation before the boss.

## Main structure

1. **Mixing Floor:** insert six guaranteed Stem Keys and activate the separate Full Mix layers.
2. **Broadcast Archives:** Beat Anchor wing.
3. **Transit Bay:** Phase Capacitor wing.
4. **Armory Bulkhead:** Breach Emitter wing.
5. **Rollback Archive:** Restore Point wing.
6. **Memory Theater:** Crew Link wing.
7. **Admin Control:** Root Credential wing.
8. **Negative Space:** final equipment/party setup, return warning, discovery of 9 Bit, fight.

All six wings are optional advantages/context. The Full Mix opens the main descent without them. The player can return to Channel Select before the final threshold.

The Mixing Floor and main descent reconstruct the minimum complete account of 9 Bit's origin before the fight. Memory Theater adds crew memories and interpretation when Crew Link is present, but the zero-module route still receives the full required context.

## Party roles

- 6 Bit: balanced damage/cadence counters/final confrontation;
- DJ: arrangement control, shields, hazard windows;
- Cache: heal, rollback, restore objects/party;
- Mac: corrupt locks/shields, burst risk damage.

Switching is expected in exploration and boss mechanics. No cameo becomes a fifth controlled party member.

## 9 Bit fight

### Reflection

Anger rush, Fear barriers, Suspicion decoys, Shame information loss; Level 7's own profile may echo Level 1's bonus-window grammar without reusing Level 1's song or timing data.

### Rejected Mix

Short callbacks to the racer, run-and-gun, puzzle, party RPG, and FPS. The original four counter different hazards.

### Negative Feedback

Close first-person duel. Six compatible layers of the separately authored Level 7 Full Mix enter as powers; Samples/community motifs arrive last. The six unrelated level songs are never layered together. Optional modules grant clear advantages without replacing skill.

## Story and ending

The player recovers the full context of the extraction before the fight, not after. 9 Bit remains accountable and dangerous. Exact resolution is owner-open: reintegration with context, contained separate existence, quarantine, or another approved outcome. Preserve working ending labels Static Burial, Ejected Echo, and The Broadcast Returns until final logic is locked.

## Secrets/community

Three final Lost Data pieces, `rat.l07`, `nulltv.l07`, community wall, discovered-echo callbacks, W3T TDDY Tower assist, Mister N1CE welcome terminal, BNL-01 status, and owner-approved archive entries. The final arena itself stays visually readable and does not become a cameo collage.
