# Level 2 — The Cache Line

**Historic sector:** Cache Back's Subway  
**Lead:** Cache Back  
**Reference:** Rad Racer  
**Mode:** behind-vehicle pseudo-3D data rail/highway  
**First-clear target:** 12–15 minutes  
**Lore:** 4 pieces

## Premise

Cache Back pilots a recovery vehicle through an impossible elevated subway/data expressway connecting corrupted sectors. The camera, road projection, traffic, hills, route forks, time checkpoints, and roadside scale provide the reference grammar. The player drives; this is not an auto-run lane selector.

## Core loop

- steer, accelerate, brake, draft, pass traffic;
- read authored traffic formations tied to this song's sections/cues where useful;
- reach time checkpoints;
- choose safe or risky forks;
- recover cache packets and optional routes;
- use Cache Back's recovery identity through checkpoint integrity, not rewind spam.

Clean passes through authored music-cue gates build boost and can bring in arrangement layers. Exact beat/downbeat judgment is optional until the Level 2 song and profile are approved. Missing a cue loses a bonus, never steering or speed controls.

## Sections

1. Crosstown warm-up and first checkpoint.
2. Crowline overpass traffic patterns.
3. Weather-corrupted tunnel with Galaknoise warnings.
4. Route fork: safe MZK-Queen Route or harder scenic Phase Capacitor route.
5. Rolling authorization blockade.

## Boss — Tollkeeper

A moving multi-lane scanner wall. Draft behind traffic, change lanes through openings, overload three pylons, then sprint through a collapsing toll tunnel. It never becomes a stationary health bar.

## Rewards

- guaranteed: `stem.bass`;
- optional hard fork: `module.phase_capacitor`;
- lore: `lore.l02.01`–`lore.l02.04`;
- hidden: `rat.l02`, `nulltv.l02`;
- story ally: W3T TDDY Transmission supplies a guaranteed, non-missable route credential that later reveals/presents Tower access. The six Stem Keys remain the only Level 7 unlock condition.

## Asset minimum

Cache driver portrait/reactions, player vehicle states, 5–7 traffic vehicles, track/horizon/skyline segments, signs/forks/obstacles/checkpoints, Tollkeeper phases, route HUD.

## Candidate echoes

Cruz Control garage, MZK-Queen Route, W3T TDDY Transmission, Galaknoise Weather, Chino-Seventy-Four service bay, Freeboot checkpoint, Wulfspace Relay, Dr3wB4by Blue decal.
