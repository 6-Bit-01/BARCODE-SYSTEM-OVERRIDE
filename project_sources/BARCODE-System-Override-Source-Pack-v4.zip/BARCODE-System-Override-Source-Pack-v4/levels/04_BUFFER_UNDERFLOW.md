# Level 4 — Buffer Underflow

**Historic sector:** Rhythm Field  
**Lead:** DJ Floppydisc  
**Reference branch:** Dr. Mario  
**Mode:** linked-pair frequency-matching puzzle  
**First-clear target:** 12–15 minutes  
**Lore:** 4 pieces

## Premise

Corruption floods the audio buffer. DJ Floppydisc drops linked two-band Patch Plugs into a diagnostic grid and clears malware packets by aligning four matching frequency symbols.

## Core grammar

- move/rotate paired pieces;
- fast drop;
- color + symbol/pattern matching;
- cascades/chains;
- preview queue;
- garbage insertion and rising pressure;
- story boards and optional challenge board.

Patch Plugs are audio connectors/waveform blocks, not pills. Each clear restores an instrument layer; cascades remix the track. All controls work independently of the beat.

## Structure

1. clean calibration board;
2. two-color infection board;
3. garbage/locked-cell board;
4. reconstructed separation log interlude;
5. Memory Leak boss board;
6. optional Restore Point challenge.

## Boss — Memory Leak

Telegraphed fragmented-row insertion, preview interference, and marked-cell deletion. Pressure never changes without visible/audio warning. Story difficulty offers a no-pressure branch.

## Rewards

- guaranteed: `stem.synth`;
- optional board: `module.restore_point`;
- lore: `lore.l04.01`–`lore.l04.04`;
- hidden: `rat.l04`, `nulltv.l04`;
- story: separation record recovered; initiator field missing.

## Asset minimum

DJ portrait/reactions, Patch Plug and malware symbols, Memory Leak states. Grid, queue, cascades, accessibility symbols, and remix UI should be code-native.

## Candidate echoes

Tonal Oracle, OREAGANOMIX preset, LoST M4RBLES score, Melancholy Heartware + August Heatglass programs, M1ND_FANATIC diagnostic signature, SKELLA Choir cascade.

