# Level 1 — Dead Air District

**Historic sector:** Cyberpunk City  
**Lead:** 6 Bit  
**Grammar:** Earthworm Jim-era platform action + compact belt-brawler arenas  
**First-clear target:** 15–18 minutes  
**Lore:** 3 pieces

## Goal

Turn the current flat sandbox into the campaign-quality vertical slice while preserving approved art and simple movement.

## Five-part layout

1. **Boot Alley:** move, single jump, normal attack, beat bonus. Short, in-world, skippable on replay.
2. **H3LLCAT Block:** additive awnings, speaker stacks, shelter, cables, scaffolds, crates, dumpsters, and signs create a lower safe route and upper secret route.
3. **Dead Channel Plaza:** first locked arena. Working choreography uses approved hi-hat/snare/attack markers from the eventual Level 1 profile; every attack still has a readable visual tell if that mapping changes.
4. **Flyby Row:** three approved flying cars become authored music-cue setpieces. Foreground flybys receive audio/visual warnings and may be spectacle or fair hazards.
5. **Relay Stage:** the jammer cuts/distorts the signal as a scripted environment trigger, opens the final arena, and leads directly into the boss.

## Controls/combat contract

- left/right;
- one jump;
- normal attack always deals base damage;
- good timing adds damage/stagger;
- perfect timing builds combo/signal recovery;
- short terminal-bound hack restores one health segment on success;
- no double jump, wall slide, Beat Dash, slide, fast-fall invulnerability, or 999-damage stomp.

R may expose the timing overlay/focus presentation, but entering it must not freeze 6 Bit or be required before attacks work. Final action bindings are implemented through the action map, not hard-coded UI text.

## Enemy roles

- **Virus:** airborne pressure; low health; hi-hat entry cue.
- **Corrupted:** fast ground pursuer; readable stop/stare then snare commit.
- **Firewall:** heavy space controller; shield/lunge on an authored Level 1 cue.

Consolidate the duplicate enemy definitions before tuning. Remove random endless flow; encounters come from authored spawn groups/milestones.

## Boss

Working concept: **The Program Director**, an automated compliance/broadcast machine that uses tracking lights, censor-bar hazards/platforms, a boom-mic sweep, and an exposed ON AIR core at authored cadence windows.

Open: existing sector-boss art must be visually approved for this identity. If it does not fit, create a new boss rather than forcing the name.

## Rewards

- guaranteed: `stem.voice`;
- optional upper route: `module.beat_anchor`;
- lore: `lore.l01.01`–`lore.l01.03`;
- hidden: `rat.l01`, `nulltv.l01`.

## Current assets to preserve

BG, FG, title, intro, three ship GIFs, 6 Bit animations, Virus, Corrupted, Firewall, jammer presentation, old boss inventory, particles, audio, and UI. Fix BG aspect ratio without redrawing it. New readable prop/collision overlays are additive.

## Candidate echoes

H3LLCAT Alley, EMRLD Channel, Crowline graffiti, Mister N1CE kiosk, Cliff maintenance note, Studio Rat, hidden Dead Channel.

## Completion definition

No kill quota. The level completes after authored traversal/arenas, the jammer event, boss victory, three collectible placements, result screen, Voice Stem Key award, and persistent save.
