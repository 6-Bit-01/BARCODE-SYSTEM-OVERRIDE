# Agent Guidance

Before editing, read `PROJECT_INSTRUCTIONS.md`, `DECISION_REGISTER.md`, `CURRENT_STATE.md`, the relevant level brief, and the repository's current `AGENTS.md`.

## Inspect first

Confirm the repository, branch, base SHA, open PRs, active script order, and dirty-worktree state. PR #4 is owner-rejected: do not merge it, copy from it, or stack work on its branch. If it remains open, report that fact and continue only from current `main`.

## Scope control

One PR should have one runtime risk theme and one owner-test route. Small adjacent fixes are allowed when they are required to make the same behavior truthful. Do not combine a lifecycle rewrite, an enemy rewrite, and a full level build in one PR.

## Preserve user work

Do not replace intro art, existing Level 1 assets, or approved dialogue. Do not rename external asset IDs casually. Do not delete legacy sources until current load/reference status is proven and an archive/removal decision is documented.

## Runtime truth

Static checks are necessary but not sufficient. A green test suite does not prove Makko import, audio policy behavior, sprite playback, visual alignment, timing feel, pause, restart, or external asset reachability.

## Genre isolation

Each genre level owns its simulation, renderer, and music-profile data behind the Level Adapter contract. Shared services own campaign state, settings, input actions, the currently active music session, assets, events, and transitions. No global BPM or cue map exists. Levels may not leave global listeners, timers, sources, or DOM overlays behind.

## Copyright and parody boundary

Use the named reference games for camera, pacing, genre grammar, and player expectation. Do not copy their characters, names, music, dialogue, code, maps, art, item silhouettes, logos, or UI trade dress.
